# NHỮNG NỘI DUNG CẦN BỔ SUNG

## Thông tin đã xác nhận

- Sinh viên: Trần Quốc Trung; MSSV: 20200648.
- Giảng viên hướng dẫn: Trần Hải Anh.
- Lớp: ICT-01 K65; học kỳ: 2026.1.
- Không suy luận trường hoặc khoa từ tên lớp, MSSV hay tên giảng viên.

## Cần bổ sung trước khi nộp chính thức

1. **Tên trường, khoa/viện, ngành/chuyên ngành, địa điểm và mẫu bìa chính thức.** Bìa đang để [CẦN BỔ SUNG] ở trường và khoa.
2. **Lời cảm ơn và lời cam đoan do sinh viên hoàn thiện, kiểm tra và ký.** Không tạo thay một cam kết cá nhân hoặc tự nêu người tham gia chưa được xác nhận. Cần kiểm tra quy định của trường về công cụ hỗ trợ viết và trích dẫn nguồn mã.
3. **Ảnh giao diện từ ứng dụng thật:** trang chủ, tìm kiếm/lọc, chi tiết sản phẩm với hai nguồn gợi ý, giỏ/checkout, tài khoản và các trang quản trị quan trọng. Chưa có phiên trình duyệt/ảnh thật được kiểm chứng; không dựng screenshot giả. Thư mục hình hiện gồm sơ đồ kỹ thuật và biểu đồ kết quả.
4. **Dữ liệu MongoDB thực tế đã ẩn danh và cấu hình chạy hợp lệ:** số bản ghi từng collection, trạng thái đơn, index, phiên bản MongoDB, URL bản triển khai. Dữ liệu 1.000 đơn được mô tả là demo tái tạo offline; không khẳng định DB đang chứa 1.000 đơn.
5. **Kiểm thử MongoDB thật:** test GR2 mặc định bỏ qua và chưa chạy với RECO_DB_IT=1. Cần lưu log xác nhận đọc DB và không thay đổi dữ liệu. Không cần cung cấp mật khẩu hoặc chuỗi kết nối bí mật trong báo cáo.
6. **Kiểm thử Shop/Admin và E2E trên trình duyệt:** chưa chạy test React hoặc đặt hàng qua bản triển khai thật trong phiên khảo sát. Backend: đã chạy Node v20.20.2, 264 test / 263 pass / 1 skip / 0 fail.
7. **Dữ liệu đơn thật và đo hiệu quả thực tế** nếu muốn bảo vệ nhận định về hành vi khách hàng, click, chuyển đổi hoặc doanh thu. Kết quả hiện có chỉ dựa dữ liệu giả lập cài sẵn luật; không được dùng thay A/B test.
8. **Mục tiêu và kiểm thử hiệu năng hệ thống:** CPU/RAM server, số request đồng thời, độ trễ p95/p99, tải DB và cache. Thời gian benchmark trong báo cáo là artifact cũ của máy i7-1255U/Node 20/Windows, không phải số đo độ trễ production.
9. **Xác nhận quy tắc học từ trạng thái đơn:** loader hiện đọc mọi đơn, bao gồm đơn hủy/chờ; muốn chỉ học đơn hoàn thành phải thay mã và đánh giá lại. Báo cáo hiện mô tả đúng loader đang có.
10. **Tri thức tương thích sản phẩm có cấu trúc và chuyên gia xác nhận.** M2 chỉ suy dòng máy từ tên; sạc/cáp/tai nghe/pin được giả định dùng chung. 100% tuân thủ trong bảng chỉ là thỏa chính các ràng buộc A2–A4.
11. **Tích hợp M1–M3 nếu phạm vi bảo vệ yêu cầu chạy trực tiếp trên website.** Hiện chúng là nghiên cứu offline; ?research=1 chỉ quan sát Apriori/FP-Growth một cấp. Không thay phát biểu này nếu chưa có mã tích hợp và bằng chứng kiểm thử.
12. **Chuẩn trích dẫn/mẫu báo cáo của trường:** đang dùng số [1]–[11], tài liệu thật và mục sách đã đối chiếu; chưa kiểm tra trực tuyến toàn văn các trang công nghệ. Bổ sung ngày truy cập thực tế nếu mẫu yêu cầu. Sách cục bộ có trang bản quyền 2012; không tự đổi số trang hoặc số mục theo một ấn bản khác.

## Lưu ý với bản bàn giao

- Word: A4, Times New Roman 13, giãn dòng 1,5; lề trái 3 cm, các lề còn lại 2 cm; Heading 1–3, công thức OMML, số trang và trường mục lục/danh mục tự động.
- **Mở DOCX bằng Microsoft Word, Ctrl+A rồi F9 (hoặc chọn Update Field) và chọn cập nhật toàn bộ mục lục.** Trường tự động có cờ updateFields; môi trường này không có Word/LibreOffice để tính sẵn số trang của Word. Chưa xác nhận bố cục trang bằng trình render DOCX thật.
- PDF 84 trang được xuất độc lập từ cùng nội dung Markdown bằng XeLaTeX; nội dung chính Chương 1–7 gồm 62 trang. PDF có mục lục/danh mục và số trang đã tính, nhưng không phải bản render trực tiếp của DOCX, nên phân trang Word có thể khác.
- Môi trường không có Times New Roman để render PDF: PDF dùng Liberation Serif 13 làm font thay thế. DOCX vẫn chỉ định Times New Roman. Nếu cần PDF trùng khớp hoàn toàn Word/font trường yêu cầu, cập nhật trường và xuất lại PDF từ Word trên máy có Times New Roman.
- Bảng số và biểu đồ Chương 6 lấy từ JSON/Markdown lưu trong repository, không tự tạo benchmark. Các ví dụ mới nằm trong bang_chung/examples.json và được tách khỏi benchmark.
- Không chạy seed DB, không triển khai website, không sửa source nghiệp vụ để tạo báo cáo. Dependency backend được cài để chạy test; runtime Node 20 được cài riêng trong work/.
- Môi trường từ chối tạo đường dẫn đầu ra /codex/... do quyền hệ thống tệp; tài liệu được lưu tại /workspace/output. Đây là giới hạn vị trí lưu, không phải thiếu nội dung tài liệu.
