# Khảo sát kiến trúc TrungShop

Snapshot HEAD: a9c5a23280b695467aac045a36079c9dbf543163. Ngày khảo sát: 02/11/2026.

## Bản đồ hệ thống

- Shop/Shop/frontend: React 18, Router, Redux và Axios. Trang ProductDetails gọi FrequentlyBoughtTogether.
- Admin/Admin: ứng dụng React quản trị riêng; backend kiểm quyền độc lập với UI.
- Shop/Shop/backendapi: Express /api/v1 → router/middleware → controller → Mongoose và các hàm thư viện.
- Collection: categories, products, users, orders, comments, coupons. Items/địa chỉ/coupon/status_history nhúng trong orders; không có collection mô hình luật trong luồng hiện tại.
- Mining: src/apps/services/mining, thuần JS; normalization, Apriori, FP-Growth, generateRules và ruleMeasures.
- Recommendation: loaders đọc mọi đơn và sản phẩm; service cache snapshot/mô hình; ranking chỉ dùng luật 1→1 có lift>1, loại trùng/thiếu/hết hàng rồi fallback.
- M1/M2/M3: research/multilevel, research/constraints, research/ranking. Chưa có đường gọi từ router hiện hành vào ba mô hình này.

## Luồng mặc định đã đối chiếu

ProductDetails → FrequentlyBoughtTogether → getRecommendations → GET recommendations/products/:id → createRecommendationService → loader/transactionsFromOrders → mine → indexSingleItemRules/rankRecommendations → attachPricing → UI phân source.

Mặc định FP-Growth, minSupport .01, minConfidence .2, tối đa 5. Cache TTL 10 phút, fingerprint interval 30 giây; fingerprint chỉ số đơn và ID lớn nhất. Query API cho phép đổi Apriori/FP-Growth, chưa cho chọn M1–M3.

## Kết quả và giới hạn quan trọng

- Test mới với Node v20.20.2: 264 tests, 263 pass, 1 skip (MongoDB thật), 0 fail.
- Node 24 gặp lỗi tương thích dependency config trong các test có nạp cấu hình.
- Kết quả nghiên cứu R1/R1b là dữ liệu giả lập có companion cài sẵn; thời gian lưu từ máy khác, không phải benchmark chạy mới.
- M1 có thể khái quát hóa nhưng gợi ý sai model phụ kiện; M2 dùng heuristic tên; M3 đa dạng fallback cũng có thể tạo phần lớn hiệu quả nhóm hiếm.
- Giá lấy từ DB khi đặt hàng; tồn kho chỉ Boolean; tạo đơn chưa đồng nghĩa thanh toán thành công.
- Mining đọc mọi status, khác điều kiện doanh thu chỉ delivered.
- Manifest 260 tệp JS/JSX/CSS ngoài public và các artifact liên quan trong bang_chung.

Chi tiết hợp đồng module, sơ đồ dữ liệu, API, lý thuyết và số liệu nằm trong báo cáo Chương 3–6 và phụ lục. Danh sách thiếu dữ liệu và hạn chế xuất Word/PDF được ghi ở NHUNG_NOI_DUNG_CAN_BO_SUNG.md.
