# Bàn giao báo cáo TrungShop

Sinh viên Trần Quốc Trung – 20200648; lớp ICT-01 K65; GVHD Trần Hải Anh; học kỳ 2026.1.

- Bao_cao_do_an_tot_nghiep_TrungShop.docx: Word có Heading, công thức, bảng/hình, số trang và trường mục lục tự động. Mở Word, Ctrl+A rồi F9 để tính mục lục/số trang Word.
- Bao_cao_do_an_tot_nghiep_TrungShop.pdf: 84 trang; Chương 1–7 có 62 trang; PDF xuất độc lập từ cùng nội dung, dùng Liberation Serif vì môi trường thiếu Times New Roman. Không phải bản render trực tiếp của DOCX.
- hinh_anh_so_do/: 8 sơ đồ DOT/SVG/PNG, 2 biểu đồ SVG/PNG và dữ liệu nguồn.
- NHUNG_NOI_DUNG_CAN_BO_SUNG.md: thông tin trường/khoa, cam đoan/cảm ơn, ảnh UI thật, kiểm chứng triển khai và các giới hạn.
- KHAO_SAT_KIEN_TRUC.md: bản đồ hệ thống và kết luận tích hợp.
- Bao_cao_do_an_tot_nghiep_TrungShop.md: nội dung nguồn chỉnh sửa được.
- bang_chung/: kết quả nghiên cứu gốc, manifest mã nguồn, ví dụ chạy mới và log test Node 20.

Backend kiểm thử mới: 264 test, 263 pass, 1 skip cần MongoDB thật, 0 fail. M1–M3 chỉ offline, chưa tích hợp mặc định. Các benchmark trong báo cáo là kết quả đã lưu trên dữ liệu giả lập, không phải số liệu người mua thật hoặc benchmark mới. Không có ảnh UI giả.

Các script trong bang_chung/nguon_bao_cao lưu để đối chiếu quá trình tạo; chúng dùng đường dẫn của môi trường khảo sát và cần điều chỉnh nếu chạy ở máy khác. Nguồn triển khai thuật toán là repository được khảo sát, không chép toàn bộ vào gói này.
