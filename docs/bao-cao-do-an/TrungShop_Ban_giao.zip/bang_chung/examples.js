const fs=require('fs');
const B='/workspace/Product-Recommendation/Shop/Shop/backendapi/';
const {generateResearchDataset}=require(B+'research/datasets/generator');
const {temporalSplit}=require(B+'research/evaluation/split');
const {mine}=require(B+'src/apps/services/mining');
const {rankRecommendations,indexSingleItemRules}=require(B+'src/apps/services/recommendation/ranking');
const M1=require(B+'research/multilevel/recommender');
const C=require(B+'research/constraints/recommender');
const R=require(B+'research/ranking/recommender');
const ds=generateResearchDataset({profile:'r1b',seed:20261101,count:20000});
const s=temporalSplit(ds.orders),h=[...s.train,...s.validation];
const params={algorithm:'fpgrowth',minSupport:.002,minConfidence:0,productMinSupport:.002,categoryMinSupport:.005,policy:'specific-first',k:5};
const f=M1.fitMultilevel(h,ds.products,params),m1=M1.buildModel(f,params);
const m2=C.constrainedFlatRecommender({...params}).fit(h,ds.products);
const flat=mine(h.map(o=>o.items),{algorithm:'fpgrowth',minSupport:.002,minConfidence:0});
const byId=new Map(ds.products.map(p=>[p._id,p])); const counts=new Map();h.forEach(o=>o.items.forEach(i=>counts.set(i,(counts.get(i)||0)+1)));
const example={checksum:ds.checksum,history:h.length,stats:f.mining.stats,queries:[]};
for(const key of ['iphone-15-128','galaxy-s24-fe',ds.products[0].key]){
 const p=ds.products.find(p=>p.key===key);if(!p||example.queries.some(q=>q.id===p._id))continue;
 const lookup=x=>({...x,name:byId.get(x.productId)?.name});
 const r=R.rankedRecommender({base:'flat',baseParams:params,rank:{strategy:'kulc-ir',beta:.5,lambda:.75},k:5}).fit(h,ds.products);
 example.queries.push({id:p._id,key:p.key,name:p.name,support:counts.get(p._id),flat:rankRecommendations({productId:p._id,ruleIndex:indexSingleItemRules(flat.rules),productsById:byId,itemCounts:counts},{limit:5}).items.map(lookup),m1:m1.explain(p._id).map(lookup),m2:(m2.explain?m2.explain(p._id):m2.recommend(p._id)).map(lookup),m3:r.explain(p._id).map(lookup)});
}
fs.writeFileSync('/workspace/work/examples.json',JSON.stringify(example,null,2));
console.log(JSON.stringify(example.queries.map(q=>({name:q.name,support:q.support,flat:q.flat.map(i=>[i.name,i.source]),m1:q.m1.map(i=>[i.name,i.source,i.score]),m2:q.m2.map(i=>[i.name,i.source]),m3:q.m3.map(i=>[i.name,i.source,i.score])})),null,2));
