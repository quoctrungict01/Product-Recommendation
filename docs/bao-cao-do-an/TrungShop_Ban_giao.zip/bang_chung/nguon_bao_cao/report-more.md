# CHƯƠNG 3. PHÂN TÍCH VÀ THIẾT KẾ HỆ THỐNG

## 3.1. Khảo sát bài toán

TrungShop quản lý danh mục điện thoại và phụ kiện, cho phép khách duyệt hàng, xem thông tin, lập giỏ và gửi đơn. Thành viên có thêm hồ sơ, địa chỉ mặc định, lịch sử đơn và quyền bình luận. Quản trị viên làm việc qua một ứng dụng React riêng, nhưng mọi quyền ghi vẫn được kiểm tra ở backend. Tách UI giúp tổ chức nghiệp vụ; nó không thay thế kiểm soát truy cập của API.

Dữ liệu đơn hàng vừa phục vụ vận hành vừa làm nguồn mining. Hai mục đích dùng quy tắc khác nhau: doanh thu chỉ ghi nhận đơn đã giao, trong khi loader gợi ý hiện tại đọc mọi đơn, không lọc trạng thái. Do đó không thể gọi đầu vào mining là “toàn bộ giao dịch mua thành công”. Đây là quyết định hiện thực cần được nêu rõ khi giải thích kết quả và là điểm cần cải tiến khi chuyển sang dữ liệu thật.

## 3.2. Yêu cầu chức năng

Bảng 3.1 tổng hợp phạm vi có bằng chứng trong router, controller và component. “Có trong mã” thể hiện hiện thực được tìm thấy, không thay cho xác nhận mọi luồng đã chạy trên một bản triển khai thật.

| Mã | Chức năng | Bằng chứng chính | Trạng thái |
|---|---|---|---|
| F01 | Đăng ký, đăng nhập | `routers/auth.js`, controller `auth.js` | Có trong API và Shop |
| F02 | Hồ sơ, địa chỉ, đổi mật khẩu | `/auth/me`, `pages/Account` | Có trong API và Shop |
| F03 | Danh sách, chi tiết sản phẩm | `product.js`, `ProductBrowser.js` | Có trong API và Shop |
| F04 | Tìm kiếm, lọc giá, danh mục, tồn kho | `libs/product-query.js` | Có trong API và UI |
| F05 | Giỏ hàng, gửi đơn, coupon | reducer `cart.js`, controller `order.js` | Có trong mã |
| F06 | Lịch sử đơn của thành viên | `/order/my`, `Account/Orders.js` | Có trong mã |
| F07 | Bình luận và xóa bình luận | product router, comment router | Thành viên viết; admin quản lý |
| F08 | Quản trị sản phẩm, danh mục | các route create/update/delete | Admin; có quy tắc chặn xóa |
| F09 | Quản trị đơn, chuyển trạng thái | `order-status.js`, `Order/Detail.js` | Admin |
| F10 | Coupon và thống kê | coupon/stats router, Admin pages | Admin |
| F11 | Gợi ý luật một cấp và fallback | `recommendation/service.js`, FBT component | Đã nối vào trang chi tiết |
| R01 | M1 đa cấp độ | `research/multilevel` | Nghiên cứu offline |
| R02 | M2 ràng buộc | `research/constraints` | Nghiên cứu offline |
| R03 | M3 xếp hạng/đa dạng | `research/ranking` | Nghiên cứu offline |

*Bảng 3.1. Chức năng và trạng thái theo mã nguồn.*

Không đồng nhất trạng thái “có mã và test” với “đã hoàn thiện vận hành”. Những phần phụ thuộc cấu hình, database hoặc trình duyệt cần bằng chứng triển khai bổ sung. Các giới hạn còn lại được liệt kê riêng, thay vì dùng một nhãn hoàn thiện chung cho toàn bộ website.

## 3.3. Yêu cầu phi chức năng

Yêu cầu bảo mật suy ra từ hiện thực là không tin giá hoặc vai trò do client gửi, giới hạn dữ liệu đầu vào, tránh lộ password/hash và kiểm tra chủ thể của tài nguyên. JWT chỉ cung cấp định danh ban đầu; middleware đọc lại tài khoản và role từ DB. CORS giới hạn origin theo cấu hình, các route đăng nhập/đăng ký và preview coupon có rate limiter. Những cơ chế này giảm một số rủi ro, chưa phải chứng nhận bảo mật toàn diện.

Yêu cầu hiệu năng gồm phân trang danh sách, projection bỏ `details` khi tải danh sách sản phẩm, cache mô hình và chỉ đọc trường cần cho mining. Đường lọc giá hiện tính trong bộ nhớ nên chỉ phù hợp quy mô danh mục nhỏ; không có cơ sở đặt cam kết độ trễ hoặc số người dùng đồng thời. [CẦN BỔ SUNG: mục tiêu tải, độ trễ p95, dung lượng dữ liệu, tài nguyên máy và báo cáo kiểm thử tải.]

Yêu cầu khả năng giải thích được hiện thực bằng luật nguồn, số đếm và nhãn fallback. Yêu cầu bảo trì được hỗ trợ nhờ tách thuật toán thuần khỏi Mongoose, tiêm loader vào service và có các bộ kiểm thử. Yêu cầu tái lập nghiên cứu được hỗ trợ bằng seed, phiên bản bộ sinh, checksum, giới hạn tiến trình và lưu kết quả JSON.

## 3.4. Đối tượng sử dụng hệ thống

Khách chưa đăng nhập có thể xem sản phẩm, gợi ý, bình luận và gửi đơn. API hỗ trợ đặt hàng không tài khoản; tuy nhiên giỏ của khách không được lưu lâu dài bằng hàm `saveCartToStorage` vì hàm này yêu cầu userId. Không nên suy ra rằng khách có một giỏ đồng bộ trên server.

Thành viên có các quyền của khách và thao tác với hồ sơ của chính mình, đổi mật khẩu, xem đơn có `user_id` khớp token, viết bình luận bằng danh tính đã xác thực. Quản trị viên có các trang quản lý, đổi trạng thái và thống kê. Việc cấp mới quyền admin không được thực hiện tùy ý qua API quản lý người dùng; mã hướng đến script `scripts/create-admin.js`.

![Hình 3.1. Sơ đồ use case theo các quyền hiện có; quan hệ nối biểu thị quyền sử dụng.](hinh_anh_so_do/uc.png)

Sơ đồ chỉ gom các use case có route hoặc UI tương ứng. “Đặt hàng” không bao gồm một use case thanh toán trực tuyến chưa được chứng minh. Nghiên cứu M1–M3 không đặt trong quyền của khách hoặc admin vì các script chạy offline bên ngoài website.

## 3.5. Phân tích nghiệp vụ

Luồng bán hàng bắt đầu từ chọn sản phẩm và cập nhật giỏ trong trình duyệt. Khi mở giỏ, frontend tải lại thông tin sản phẩm để cập nhật giá và tình trạng. Khi gửi đơn, backend kiểm tra lại toàn bộ đầu vào và tính lại giá từ DB. Nếu có token, `optionalAuth` xác thực và gắn tài khoản; token sai bị từ chối thay vì âm thầm chuyển thành khách.

Mã giảm giá là tài nguyên có thể bị tranh chấp khi nhiều đơn dùng lượt cuối. `reserveCoupon` tăng `used_count` bằng một cập nhật có điều kiện; khi lưu đơn thất bại, `releaseCoupon` cố gắng trả lượt. Đây là bù trừ giữa các thao tác riêng, không phải transaction đa tài liệu. Nếu tiến trình dừng sau giữ lượt nhưng trước lưu đơn, cơ chế hiện tại chưa chứng minh tự phục hồi lượt.

![Hình 3.2. Luồng xử lý đặt hàng theo controller `order.js`.](hinh_anh_so_do/order.png)

Đơn mới ở `pending`. Admin chỉ được chuyển theo đồ thị quy định; giao hàng thành công ghi `delivered_at`. Đơn cũ thiếu status được diễn giải là pending, không tự cập nhật hàng loạt. Khi hai admin cùng thay đổi, filter trạng thái cũ trong `findOneAndUpdate` giúp một yêu cầu sau có thể nhận 409 thay vì ghi đè im lặng.

![Hình 3.3. Máy trạng thái đơn hàng từ `TRANSITIONS`.](hinh_anh_so_do/status.png)

## 3.6. Kiến trúc tổng thể

Backend là một ứng dụng Express với các nhóm router, controller, model và service, không phải tập microservice độc lập. Các module mang tên `services/mining` và `services/recommendation` chạy trong tiến trình Node của API. Điều này quan trọng đối với độ trễ: mining đồng bộ có thể giữ event loop ngay cả khi các phần đọc DB được gọi bằng Promise.

![Hình 3.4. Kiến trúc TrungShop và ranh giới nghiên cứu offline.](hinh_anh_so_do/architecture.png)

Shop và Admin gửi HTTP tới API mặc định `/api/v1`. Express thực hiện CORS, parse body với giới hạn 100 KB, định tuyến, xử lý lỗi JSON và phục vụ tài nguyên tĩnh. Controller phụ trách HTTP và nghiệp vụ; các model truy cập MongoDB. Recommendation service gọi loader để lấy đơn và sản phẩm, rồi dùng module mining và ranking. Nhánh research tái sử dụng các hàm thuật toán nhưng không có đường gọi từ router mặc định vào M1–M3.

## 3.7. Thiết kế cơ sở dữ liệu MongoDB

Mỗi collection có trường nghiệp vụ và `timestamps`. Quan hệ tham chiếu dùng ObjectId hoặc chuỗi mã; quan hệ nhúng dùng subdocument. Orders nhúng items vì mỗi dòng thuộc vòng đời một đơn và cần lưu giá/qty lịch sử. Địa chỉ giao hàng được chụp vào đơn thay vì luôn đọc địa chỉ hiện tại từ tài khoản; việc người dùng đổi hồ sơ không làm đổi nơi giao của đơn đã gửi.

| Collection | Thuộc tính nổi bật | Ý nghĩa thiết kế |
|---|---|---|
| `categories` | `name` | Danh mục phẳng, không có parent |
| `products` | `name`, `category_id`, `price`, `promotion`, `is_stock` | Giá và promotion lưu String; trạng thái còn hàng Boolean |
| `users` | `email`, `password`, `role`, `address`, `password_changed_at` | Email unique; mật khẩu băm; địa chỉ nhúng |
| `orders` | `user_id`, `items`, `status`, `totalPrice`, `coupon`, `status_history` | Lưu lịch sử giá, coupon và trạng thái |
| `comments` | `name`, `email`, `content`, `product_id` | Danh tính chụp tại lúc viết; product_id là String |
| `coupons` | `code`, `type`, `value`, `used_count`, `usage_limit` | Hạn thời gian, hạn lượt và trạng thái hoạt động |

*Bảng 3.2. Các collection chính theo Mongoose Model.*

Không tự suy ra collection tên `recommendations` hoặc `rules`: service hiện giữ mô hình trong bộ nhớ tiến trình. Khởi động lại làm mất cache; các luật được khai phá lại từ orders khi cần. Các tệp `research-results/*.json` là artifact thực nghiệm, không phải collection production.

## 3.8. Phân tích các collection và quan hệ

![Hình 3.5. Sơ đồ dữ liệu MongoDB; đường đứt chỉ liên kết logic, hộp con biểu thị dữ liệu nhúng.](hinh_anh_so_do/erd.png)

Một category liên quan nhiều product; một user có nhiều order nhưng order của khách cho phép `user_id=null`. Mỗi order có nhiều dòng items; mỗi dòng tham chiếu product và lưu giá/qty. Một product có nhiều comment; comment không tham chiếu user_id mà lưu name/email nên không thể dùng schema hiện tại để khẳng định truy vết mọi bình luận đến một tài khoản bằng khóa ngoại.

Trường `products.category_id` khai báo `ref: "Category"`, trong khi model danh mục được đăng ký tên `Categories`. Đây là bất nhất cần lưu ý nếu sử dụng populate tự động. Các luồng đang đọc trực tiếp theo ID hoặc chỉ định model không vì thế mà tự động hỏng; báo cáo không quy kết mọi truy vấn lỗi, nhưng không vẽ quan hệ như một khóa ngoại được DB cưỡng chế.

MongoDB không tự bảo đảm toàn vẹn tham chiếu như khóa ngoại SQL. Controller danh mục chặn xóa khi còn sản phẩm; controller sản phẩm chặn xóa khi đã có đơn, hướng admin chuyển hết hàng. Khi được phép xóa sản phẩm, bình luận liên quan được xóa theo. Các kiểm tra và thao tác là nhiều lệnh riêng, nên cần xem xét race condition nếu nhiều tác nhân ghi đồng thời.

## 3.9. Thiết kế API

Các đường sau tương đối với `/api/v1` mặc định. Router thể hiện quyền, controller thể hiện kiểm tra nội dung; không nên suy luận quyền chỉ từ tên URL hoặc từ việc nút có hiển thị trong Admin.

| Nhóm | Phương thức và đường dẫn | Quyền | Kết quả chính |
|---|---|---|---|
| Auth | POST `/auth/register`, `/auth/login` | Công khai | Token và user an toàn |
| Hồ sơ | GET/PUT `/auth/me`; PUT `/auth/me/password` | Thành viên | Hồ sơ hoặc token mới |
| Catalog | GET `/products`, `/products/:id` | Công khai | Danh sách phân trang/chi tiết |
| Danh mục | GET `/categories`, `/categories/:id/products` | Công khai | Danh mục và sản phẩm |
| Đơn | POST `/order` | Khách hoặc thành viên | Mã đơn và tổng tiền |
| Đơn cá nhân | GET `/order/my` | Thành viên | Chỉ đơn của token |
| Đơn quản trị | GET `/order/admin`, `/order/admin/:id`; PATCH status | Admin | Danh sách/chi tiết/trạng thái |
| Gợi ý | GET `/recommendations/products/:id` | Công khai | `items`, `params`, `meta` |
| Cache | GET `/recommendations/status`; POST `/recommendations/refresh` | Status công khai; refresh chỉ loopback | Tình trạng hoặc xóa cache |
| Coupon | POST `/coupons/preview`; `/coupons/admin` | Preview công khai; admin quản lý | Xem trước hoặc dữ liệu coupon |
| Thống kê | GET `/stats/summary`, `/stats/revenue`, `/stats/top-products` | Admin | Chỉ số và dữ liệu biểu đồ |

*Bảng 3.3. API tiêu biểu đã đối chiếu router.*

API gợi ý trả 400 cho mã hoặc tham số sai, 404 khi sản phẩm không tồn tại, 503 khi không đọc được dữ liệu và 500 cho lỗi không dự kiến. Các mã lỗi cần được diễn giải đúng: không tìm thấy luật là tình huống hợp lệ có fallback, không phải cùng nghĩa với lỗi DB. Endpoint refresh kiểm tra `req.socket.remoteAddress`, không dùng role admin; đặt sau reverse proxy cần xem xét kỹ địa chỉ peer và cách giới hạn đường quản trị vận hành.

## 3.10. Thiết kế quy trình gợi ý sản phẩm

![Hình 3.6. Luồng gợi ý mặc định đã tích hợp trong trang chi tiết.](hinh_anh_so_do/recommendation.png)

Component `FrequentlyBoughtTogether` gửi productId và algorithm. Router tạo service lười, loader đọc snapshot giao dịch và danh mục. Service chọn mô hình theo snapshot version, thuật toán và ngưỡng. Ranking chỉ lấy luật 1→1, lọc lift, kiểm tra sản phẩm và điền fallback. Controller có thể gắn lại thông tin giá bán. UI chia theo `source` thành hai khu vực. Tên sản phẩm không phải đầu vào thuật toán khai phá một cấp; ID mới là mục trong giao dịch.

Thiết kế có điểm mạnh là kiểm chứng được nguồn gợi ý và dùng chung mining cho cả hai thuật toán. Hạn chế là fingerprint chỉ nhìn số đơn và `_id` mới nhất, không nhận biết mọi chỉnh sửa nội dung đơn; sản phẩm được đọc lại mỗi request nhưng dữ liệu luật có thể cũ trong TTL. Không có bằng chứng về cache phân tán hoặc chia sẻ mô hình giữa nhiều tiến trình.

# CHƯƠNG 4. XÂY DỰNG WEBSITE TRUNGSHOP

## 4.1. Môi trường và công nghệ phát triển

Shop được tổ chức theo cấu trúc Create React App với `react-scripts` 5.0.1. Backend khởi động qua `src/bin/www.js`; cấu hình mặc định dùng port 8000 và prefix `/api/v1`, cho phép biến môi trường ghi đè. Hai frontend dùng module `services/Http.js` và `services/Api.js` để đóng gói HTTP. Các dependency và lockfile là cơ sở cài môi trường, còn biến cấu hình bí mật phải do môi trường triển khai cung cấp.

[CẦN BỔ SUNG: phiên bản MongoDB đang triển khai, hệ điều hành máy phát triển của sinh viên, thông số server, URL truy cập bản chạy thật và hướng dẫn triển khai đã xác nhận. Môi trường đo benchmark cũ được trình bày riêng ở Chương 6.]

Không coi cấu hình `.env.example` là thông tin kết nối thật. Báo cáo không trích bí mật từ tệp môi trường hoặc lịch sử Git. Mục tiêu triển khai có thể tái lập là ghi lại runtime, dùng lockfile và giữ riêng thông tin cấu hình khỏi nội dung công khai của đồ án.

## 4.2. Xây dựng frontend React

`Shop/Shop/frontend/src/App.js` khai báo các trang Home, Category, Search, ProductDetails, Cart, Success, Login, Register và nhóm Account. Layout phân biệt trang mua sắm có cột banner với trang tài khoản dùng chiều rộng đầy đủ. React Router sử dụng các đường dạng `/ProductDetails-:id`, `/Category-:id` và `/account/orders`; báo cáo giữ nguyên kiểu URL thay vì thay bằng một cấu trúc REST tưởng tượng ở frontend.

`ProductBrowser` tập trung logic duyệt catalog. Các component `Product-item`, `PriceTag`, `Pagination` hỗ trợ hiển thị thống nhất. `FrequentlyBoughtTogether` nằm ngay trong trang chi tiết, tự tải gợi ý khi productId hoặc algorithm đổi. Các utility trong `shared/ultils` xử lý giá, token, địa chỉ, nội dung sản phẩm và đường dẫn tài nguyên.

Redux chia trạng thái Auth và Cart. Giỏ hàng được gắn userId khi đăng nhập và tải từ khóa `cart_${userId}`. Đăng xuất xóa giỏ khỏi state nhưng giữ bản lưu của tài khoản; đăng nhập lại có thể phục hồi giỏ đó. Đây là lưu cục bộ theo tài khoản trên một trình duyệt, không phải giỏ hàng đa thiết bị lưu trong MongoDB.

Các yêu cầu HTTP không đồng bộ có cơ chế bỏ kết quả cũ ở component gợi ý bằng cờ `cancelled`. Khi đổi sản phẩm, gợi ý cũ bị xóa ngay; khi chỉ đổi thuật toán, giao diện có thể giữ và làm mờ danh sách cũ chờ dữ liệu mới. Cờ này ngăn cập nhật state bằng response không còn phù hợp; nó không đồng nghĩa hủy tác vụ mining đã bắt đầu trên server.

## 4.3. Xây dựng backend Node.js và Express

`src/apps/app.js` cấu hình CORS theo prefix, nhận JSON/urlencoded tối đa 100 KB, gắn `routers/web.js`, trả JSON 404 cho API lạ rồi phục vụ static và xử lý lỗi cuối chuỗi. Các controller async thông thường được bọc `asyncHandler`; recommendation controller có xử lý lỗi riêng. Kiểu tổ chức giúp lỗi validation không cần làm sập tiến trình và hạn chế gửi stack trace về client.

Các lớp có trách nhiệm khác nhau: router đặt URL và middleware quyền; controller kiểm tra request và phối hợp truy vấn; thư viện như pricing, coupon, product-query thực hiện quy tắc dùng lại; service mining xử lý dữ liệu thuần. Việc tách hàm giúp kiểm thử được các quy tắc không cần khởi chạy toàn bộ website.

Một giới hạn của kiến trúc là không có hàng đợi mining trong luồng mặc định. `mine` trả kết quả đồng bộ; bọc trong async function không biến công việc CPU thành tác vụ song song. Khi dữ liệu lớn, một cache miss hoặc nhiều cấu hình ngưỡng mới có thể làm tăng độ trễ toàn bộ API trong cùng tiến trình. Đây là rủi ro có cơ sở từ đường gọi, chưa phải số đo tải thực tế.

## 4.4. Thiết kế và triển khai MongoDB

Model đặt tên collection tường minh như `products`, `orders` và `users`. Đơn hàng nhúng dòng sản phẩm, địa chỉ và lịch sử trạng thái. Sản phẩm lưu `price` và `promotion` dạng String nên cần một lớp chuyển đổi tiền trước khi so sánh số hoặc tính tổng. `withPricing` cung cấp các trường số đã tính cho API, đồng thời giữ tương thích dữ liệu cũ.

Sơ đồ không giả định transaction, sharding hay replica set khi không có bằng chứng cấu hình. Việc xử lý coupon có cập nhật nguyên tử trên một tài liệu, còn thao tác giữ lượt và lưu đơn không nằm trong cùng một transaction. Các trường tùy chọn ở order phục vụ khả năng đọc đơn cũ, đặc biệt không tự tính lại giá lịch sử từ giá sản phẩm hiện tại.

[CẦN BỔ SUNG: bản sao dữ liệu đã ẩn thông tin cá nhân và báo cáo index thực tế. Không suy ra số đơn trong DB hiện tại từ con số 1.000 được ghi trong chú thích hoặc từ script seed.]

## 4.5. Chức năng tài khoản và xác thực

Đăng ký chuẩn hóa email, kiểm tra mật khẩu mới, băm bằng bcrypt với `BCRYPT_ROUNDS=10` và luôn gán role `member`. Trường role do client gửi không được dùng để tự cấp quyền. Đăng nhập chỉ chấp nhận password đã có định dạng hash bcrypt và so sánh bằng bcrypt; tài khoản dữ liệu cũ còn mật khẩu thô không được coi là tương thích tự động.

`signAuthToken` ký HS256 với khóa `JWT_SECRET`, thời hạn `TOKEN_TTL="7d"`. Thiếu hoặc yếu khóa bị kiểm tra qua cấu hình; không có khóa mặc định để đưa vào báo cáo. Middleware `requireAuth` tra lại tài khoản và loại password, `requireAdmin` dùng role hiện tại từ DB. Vì vậy thay đổi role hoặc xóa tài khoản có hiệu lực ở request kế tiếp, không chờ token cũ hết hạn.

Đổi mật khẩu yêu cầu mật khẩu hiện tại đúng, băm mật khẩu mới, lưu `password_changed_at` và cấp token mới. Kiểm tra thu hồi dùng độ phân giải giây của `iat`; điều kiện là token có `iat` nhỏ hơn mốc đã làm tròn. Token được phát cùng giây với thay đổi có thể không bị phân biệt bởi điều kiện này. Cần nêu giới hạn này thay vì khẳng định vô hiệu tuyệt đối mọi token cũ ở độ phân giải nhỏ hơn giây.

Hồ sơ chỉ cho sửa các trường trong `PROFILE_FIELDS`; đổi email yêu cầu mật khẩu hiện tại. API `/auth/me` không nhận ID tài khoản từ URL nên giảm khả năng đọc/sửa hồ sơ người khác bằng cách thay mã. Đơn cá nhân lọc `user_id=req.user._id`, không dùng user_id từ query. Kiểm tra backend là lớp bảo vệ chính ngay cả khi UI có `RequireLogin` hoặc `RequireAdmin`.

## 4.6. Quản lý sản phẩm và danh mục

Tạo/sửa sản phẩm kiểm tra body, category tồn tại và tên trùng. Các trường `is_stock`, `is_featured` có quy tắc giữ lại giá trị khi update không gửi mới. Chức năng upload nhận trường multipart `image`, tối đa 2 MB, kiểm tra magic bytes cho JPG/PNG/GIF/WEBP và tạo tên ngẫu nhiên phía server. Giới hạn và loại tệp là điều kiện hiện thực, không chỉ dựa vào đuôi tệp từ trình duyệt.

Xóa sản phẩm trước hết đếm đơn có `items.prd_id` tương ứng. Nếu đã có lịch sử, API trả xung đột và yêu cầu chuyển trạng thái hết hàng. Nếu được xóa, controller xóa bình luận cùng sản phẩm. Danh mục có sản phẩm cũng bị chặn xóa. Quy tắc này giữ ổn định lịch sử và hạn chế mất các mục đang tham gia mining.

[CẦN BỔ SUNG: ảnh chụp giao diện quản lý sản phẩm và danh mục từ bản chạy thực tế. Các ảnh sản phẩm trong `public/images` là tài nguyên catalog, không phải ảnh chụp màn hình và không được dùng để giả làm UI đã chạy.]

## 4.7. Tìm kiếm và lọc sản phẩm

`parseProductQuery` kiểm tra các tham số đơn, không nhận object/array cho từ khóa hoặc giá. Từ khóa tối đa 100 ký tự, tối đa 8 token. `foldVietnamese` chuẩn hóa bỏ dấu để dựng các lớp ký tự dấu cho regex, còn các ký tự khác được escape. Bộ lọc yêu cầu tất cả token xuất hiện trong tên, không phụ thuộc thứ tự; đây không phải tìm kiếm ngữ nghĩa hoặc sửa lỗi chính tả tự động.

Các chế độ sort gồm newest, price_asc, price_desc, name_asc và name_desc. Với truy vấn không liên quan giá, MongoDB thực hiện count, sort, skip và limit; sắp tên sử dụng collation tiếng Việt. Khi cần lọc/sắp theo giá bán, backend đọc danh sách ứng viên đã lọc các thuộc tính khác, chạy `withPricing`, lọc giá số, sắp rồi cắt trang trong bộ nhớ.

Điều này bảo đảm ngữ nghĩa lọc theo giá sau ưu đãi, nhưng chi phí phụ thuộc tổng số ứng viên trước phân trang. Tăng pageSize không phải yếu tố duy nhất của bộ nhớ; một truy vấn giá có thể đọc nhiều bản ghi rồi mới lấy 12 sản phẩm. Hướng cải tiến là chuẩn hóa giá số và có chiến lược index/aggregation phù hợp, cần cân nhắc tương thích dữ liệu cũ.

## 4.8. Chức năng giỏ hàng

Reducer nhận ADD_TO_CART, UPDATE_CART, DELETE_ITEM_CART, REFRESH_CART_ITEMS và CLEAR_CART. Sản phẩm đã có thì cộng qty; cập nhật và xóa tạo state mới. Khi mở giỏ, `Promise.allSettled` tải lại từng product, chỉ dùng những lần tải thành công để cập nhật giá và trạng thái. Vì request lỗi không chứng minh sản phẩm còn bán, backend vẫn phải kiểm tra cuối cùng khi tạo đơn.

Giỏ của thành viên lưu theo userId trong localStorage. Hàm load có try/catch khi đọc JSON giỏ; tuy nhiên phần khởi tạo `JSON.parse(localStorage.getItem("user"))` ở reducer được gọi trực tiếp. Dữ liệu user lưu sai định dạng có thể cần xử lý bền vững hơn. Không có collection cart trong các model đã khảo sát.

Khi API tạo đơn thành công, frontend dispatch CLEAR_CART và điều hướng Success với mã đơn, tổng tiền. Nếu API lỗi, giỏ được giữ để sửa và gửi lại. Nút gửi có trạng thái chặn gửi lặp ở component, nhưng chưa thấy khóa idempotency phía API để ngăn hai request hợp lệ cùng tạo hai đơn khi mạng chập chờn hoặc client gửi lại chủ động.

## 4.9. Đặt hàng và quản lý đơn hàng

`validateItems` nhận tối đa 50 dòng; qty mỗi dòng là số nguyên 1–99. Các dòng trùng ID được gộp và chặn tổng ở 99. Backend bỏ giá từ body, đọc sản phẩm bằng `$in`, kiểm tra tồn tại, `is_stock` và giá hợp lệ. `productPricing` chuyển chuỗi tiền sang số nguyên VND; promotion dạng tiền chỉ giảm khi dương và nhỏ hơn giá gốc; promotion dạng chữ là thông tin quà tặng.

Tổng giá gốc bằng tổng original_price × qty; subtotal bằng tổng giá bán × qty; product_discount là hiệu hai tổng. Coupon giảm trên subtotal sau ưu đãi sản phẩm, mỗi đơn tối đa một mã. Tổng cuối bằng max(0, subtotal − coupon_discount). Các giá này được chụp trong order; không tính lại đơn cũ theo catalog mới.

Admin có danh sách phân trang và lọc trạng thái, tìm mã đơn, tên khách, điện thoại hoặc email. Chi tiết giữ được dòng hàng khi không còn thông tin catalog đầy đủ. Trạng thái chỉ đi theo `TRANSITIONS`, không nhảy cóc hoặc quay lui; delivered và cancelled là trạng thái cuối. Không có quyền tự hủy đơn của thành viên được chứng minh trong router; việc hủy thuộc luồng admin trước giai đoạn shipping.

API không trừ lượng hàng số vì model chỉ có Boolean. Không nên mô tả quy trình như hệ thống quản lý kho có đặt giữ và giải phóng số lượng. Điều kiện kiểm tra `is_stock` cũng chỉ phản ánh dữ liệu tại thời điểm đọc, không phải một cam kết tồn kho được khóa đến khi giao.

## 4.10. Chức năng quản trị

Admin React có Dashboard, Category, Product, User, Comment, Order và Coupon. `AdminLayout` bao `RequireAdmin`, nhưng API đồng thời áp `requireAdmin` cho từng nhóm ghi và dữ liệu nhạy cảm. Điều này bảo vệ khi người dùng gọi HTTP trực tiếp không qua giao diện.

Thống kê doanh thu chỉ nhận đơn delivered, dùng `totalPrice` đã lưu. Ngày ghi nhận ưu tiên delivered_at, rồi mốc delivered trong status_history; helper còn fallback sang updatedAt khi thiếu hai nguồn trên. Báo cáo phải nêu fallback thực tế này dù chú thích tóm tắt có thể chỉ nói hai nguồn đầu. Thống kê theo múi giờ Việt Nam UTC+7; doanh thu theo sản phẩm dùng giá dòng × qty trước coupon, không phân bổ coupon đơn cho từng sản phẩm.

Quản lý coupon có mã, kiểu fixed/percent, ngưỡng đơn, mức giảm tối đa, hiệu lực, số lượt và trạng thái bật/tắt. Mã được vô hiệu hóa thay vì xóa để giữ lịch sử. Preview không trừ lượt; đặt đơn mới giữ lượt nguyên tử. Vì dữ liệu thống kê và mining có bộ lọc khác nhau, không so trực tiếp số “đơn dùng để gợi ý” với số “đơn ghi nhận doanh thu” mà bỏ qua điều kiện trạng thái.

## 4.11. Tích hợp hệ thống gợi ý

Trang ProductDetails render `FrequentlyBoughtTogether productId={id}`. Component gọi `getRecommendations`, hàm này gọi đường `recommendations/products/${id}`. Router gắn tại `/recommendations` tạo service từ model Order và Product. Service import `mine` từ module nội bộ và `rankRecommendations` một cấp. Không có import M1–M3 trong chuỗi gọi này.

UI chỉ hiện khu vực có dữ liệu. `source="association-rule"` vào “Thường được mua cùng”; `source="fallback"` vào “Có thể bạn cũng quan tâm”. Chế độ `?research=1` hoặc `REACT_APP_RECO_RESEARCH=true` hiện nút Apriori/FP-Growth và chỉ số; đó là công cụ quan sát thuật toán một cấp, không phải công tắc kích hoạt ba mô hình nghiên cứu nâng cao.

Route cũ `/products/:id/product-suggestions` vẫn tồn tại với controller `productsuggestions.js`, nhưng không phải lời gọi của component hiện hành. Controller cũ đặt `minSup=5` rồi so với tỷ lệ cặp trên tổng đơn; với dữ liệu đơn được chuẩn hóa, tỷ lệ không vượt 1 nên điều kiện không đạt. Hơn nữa code cũ không loại trùng mục như module mới. Vì vậy không dùng route cũ để mô tả tính đúng của luồng mới hoặc gọi nó là FP-Growth đầy đủ chỉ dựa trên các đoạn comment.

[CẦN BỔ SUNG: ảnh trang chi tiết ở chế độ khách và chế độ research lấy từ phiên bản chạy thật; xác nhận API URL, dữ liệu và ngày chụp. Báo cáo hiện sử dụng sơ đồ kỹ thuật có nguồn mã, không dựng giao diện giả.]
