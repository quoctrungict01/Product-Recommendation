# LỜI CẢM ƠN {.unnumbered}

[CẦN BỔ SUNG: sinh viên viết lời cảm ơn theo quá trình thực hiện thực tế; xác nhận tên trường, khoa, giảng viên hướng dẫn và những cá nhân đã hỗ trợ. Không sử dụng nội dung này như một xác nhận về sự tham gia của người chưa được cung cấp thông tin.]

# LỜI CAM ĐOAN {.unnumbered}

[CẦN BỔ SUNG: sinh viên rà soát nguồn mã, quyền sử dụng dữ liệu, nguồn tham khảo và quy định về sử dụng công cụ hỗ trợ của cơ sở đào tạo; tự hoàn thiện, ký và ghi ngày lời cam đoan. Báo cáo này không thay thế cam kết cá nhân của sinh viên.]

# TÓM TẮT {.unnumbered}

Đề tài “Xây dựng website thương mại điện tử TrungShop kết hợp hệ thống gợi ý sản phẩm dựa trên khai phá luật kết hợp” giải quyết hai nhóm công việc: xây dựng quy trình mua bán trực tuyến và khai thác quan hệ đồng xuất hiện giữa các sản phẩm trong đơn hàng để tạo gợi ý có thể giải thích. Hệ thống gồm giao diện khách hàng React, giao diện quản trị React độc lập, API Node.js/Express và cơ sở dữ liệu MongoDB qua Mongoose. Các chức năng được xác định từ mã nguồn gồm tài khoản, danh mục, sản phẩm, tìm kiếm và lọc, giỏ hàng, đặt hàng, theo dõi đơn, quản trị đơn, mã giảm giá, bình luận và thống kê doanh thu.

Luồng gợi ý mặc định chuẩn hóa mỗi đơn thành tập mã sản phẩm, khai phá bằng FP-Growth hoặc Apriori, sinh luật và chọn các luật dạng một sản phẩm suy ra một sản phẩm có lift lớn hơn 1. Kết quả được xếp theo confidence, lift và support; sản phẩm thiếu hoặc hết hàng bị loại. Khi thiếu gợi ý từ luật, hệ thống bổ sung theo danh mục và độ phổ biến, đồng thời gắn nhãn fallback. Giao diện phân biệt “Thường được mua cùng” với “Có thể bạn cũng quan tâm”.

Ba hướng mở rộng được cài đặt và đánh giá trong nhánh nghiên cứu offline: M1 khai phá đa cấp độ, M2 áp dụng ràng buộc nghiệp vụ và cắt tỉa chống đơn điệu, M3 xếp hạng và đa dạng hóa danh mục. Đối chiếu đường gọi cho thấy ba mô hình này chưa được tích hợp vào API mặc định. Kết quả lưu trong repository trên R1/R1b cho thấy chọn tham số bằng validation có tác động lớn hơn các mở rộng còn lại; các cải thiện về recall, độ phủ và đa dạng có sự đánh đổi. Dữ liệu này là dữ liệu giả lập có quy luật cài sẵn, nên chưa đủ để kết luận về doanh thu hoặc hiệu quả với khách hàng thật.

Từ khóa: thương mại điện tử; luật kết hợp; Apriori; FP-Growth; gợi ý sản phẩm; đa cấp độ; ràng buộc; TrungShop.

# ABSTRACT {.unnumbered}

This thesis examines TrungShop, an e-commerce website with an explainable product recommendation component based on association rule mining. The implementation comprises separate React applications for customers and administrators, a Node.js/Express API, and MongoDB accessed through Mongoose. The source code supports accounts, product and category management, search and filtering, carts, order submission and tracking, coupons, comments, and revenue statistics.

The default recommendation pipeline converts orders into sets of product identifiers, mines frequent itemsets using FP-Growth or Apriori, and selects single-antecedent, single-consequent rules with lift greater than one. Candidates are ordered by confidence, lift, and support. Missing and unavailable products are removed. Category-based and popularity-based fallback items fill remaining positions and are explicitly distinguished from association-rule recommendations in both the response and the interface.

Three research extensions are implemented separately: multilevel mining (M1), business constraints and anti-monotone pruning (M2), and ranking with category diversification (M3). Source-level call tracing confirms that these extensions are offline research components rather than part of the default website pipeline. Stored experiments use the synthetic R1 and R1b datasets with embedded purchasing patterns. They show trade-offs between recall, catalog coverage, business-rule compliance, and diversity, with validation-based threshold selection accounting for the largest improvement. These findings do not establish effectiveness on real customers or causal business impact. Remaining verification and institutional metadata are explicitly identified.

Keywords: e-commerce; association rules; Apriori; FP-Growth; explainable recommendations; multilevel mining; constraints.

# DANH MỤC TỪ VIẾT TẮT {.unnumbered}

| Từ | Diễn giải |
|---|---|
| API | Application Programming Interface – giao diện lập trình ứng dụng |
| ARM | Association Rule Mining – khai phá luật kết hợp |
| CRUD | Create, Read, Update, Delete |
| FP | Frequent Pattern – mẫu phổ biến |
| IR | Imbalance Ratio – tỷ số mất cân bằng |
| JWT | JSON Web Token |
| Kulc | Kulczynski – trung bình hai xác suất có điều kiện |
| MMR | Maximal Marginal Relevance; ở đây chỉ dùng để mô tả ý tưởng tham lam |
| ODM | Object Document Mapper; Mongoose ánh xạ tài liệu MongoDB |
| PRNG | Pseudorandom Number Generator – bộ sinh số giả ngẫu nhiên |
| RSS | Resident Set Size – bộ nhớ thường trú của tiến trình |
| SD | Standard Deviation – độ lệch chuẩn |
| TTL | Time To Live – thời gian hiệu lực của cache |
| UI | User Interface – giao diện người dùng |

*Bảng 0.1. Các từ viết tắt sử dụng trong báo cáo.*

# CHƯƠNG 1. TỔNG QUAN ĐỀ TÀI

## 1.1. Lý do chọn đề tài

Một cửa hàng trực tuyến cần giúp người dùng tìm sản phẩm và hoàn thành giao dịch với số bước hợp lý. Khi danh mục có nhiều điện thoại và phụ kiện, người dùng thường biết sản phẩm chính nhưng chưa biết các sản phẩm thường được mua cùng. Chỉ hiển thị các mặt hàng cùng danh mục có thể tạo danh sách gồm các sản phẩm thay thế, trong khi nhu cầu mua kèm thường là các sản phẩm bổ trợ như ốp lưng, kính bảo vệ hoặc sạc. Dữ liệu đơn hàng cung cấp một dấu vết trực tiếp của hành vi đồng mua mà có thể khai thác mà không yêu cầu khách hàng đánh giá sao.

Luật kết hợp phù hợp với bài toán vì đầu vào có thể chỉ là các tập sản phẩm trong đơn hàng. Luật $A\Rightarrow B$ cho biết trong lịch sử, các giao dịch có $A$ thường cũng có $B$ với một mức độ đo được. Khác với một điểm dự đoán khó giải thích, luật có thể đi kèm số đơn đồng xuất hiện, confidence và lift. Đây là lợi thế khi người phát triển cần kiểm tra tại sao một sản phẩm được gợi ý và phân biệt tín hiệu dữ liệu với phương án dự phòng.

Tuy vậy, đồng xuất hiện không chứng minh quan hệ nhân quả, sự tương thích kỹ thuật hoặc nhu cầu của từng cá nhân. Một sản phẩm bán chạy có thể đồng xuất hiện với nhiều sản phẩm chỉ do phổ biến. Danh sách cùng danh mục có thể không phù hợp với mục tiêu bán phụ kiện. Đề tài vì thế nghiên cứu cả khai phá mẫu, kiểm soát chất lượng luật, ràng buộc nghiệp vụ và xếp hạng; đồng thời giữ ranh giới giữa kết quả đã tích hợp và kết quả thực nghiệm.

## 1.2. Mục tiêu nghiên cứu

Mục tiêu phần mềm là khảo sát và mô tả đúng một website có chu trình từ duyệt hàng đến lưu đơn, xác thực người dùng, quản trị dữ liệu và hiển thị gợi ý mua kèm. Mục tiêu thuật toán là trình bày, kiểm chứng hai cách khai phá tập phổ biến cùng cơ chế sinh luật và đo lường quan hệ. Mục tiêu thực nghiệm là đánh giá ảnh hưởng của ngưỡng, phân cấp, ràng buộc và thứ tự ứng viên trong một giao thức tránh sử dụng dữ liệu tương lai để học.

Báo cáo không đặt mục tiêu chứng minh tăng doanh thu do chưa có thử nghiệm kinh doanh đối chứng. Mục tiêu có thể kiểm tra được là tính đúng của đầu ra khai phá, quan hệ giữa API và UI, cách lọc ứng viên, khả năng tái lập dữ liệu giả lập, và mức đánh đổi của các mô hình theo các chỉ số offline.

## 1.3. Đối tượng và phạm vi nghiên cứu

Đối tượng là mã nguồn trong repository `Product-Recommendation`, tập trung vào `Shop/Shop/backendapi`, `Shop/Shop/frontend` và `Admin/Admin`. Trong các chương sau, đường dẫn bắt đầu bằng `src/`, `research/`, `scripts/` hoặc `test/` được hiểu tương đối với thư mục backend, trừ khi ghi rõ Shop hoặc Admin. Các tên tệp và hàm được giữ theo mã nguồn, kể cả cách viết `ultils` trong frontend.

Phạm vi tích hợp gồm luật kết hợp một cấp trong trang chi tiết sản phẩm. M1–M3 nằm trong `research/`, phục vụ phân tích offline. Dữ liệu thực nghiệm R1 có 41 sản phẩm, R1b có 48 sản phẩm, trong đó 7 sản phẩm bổ sung để khảo sát tình huống ít giao dịch. Đây là danh mục của bộ sinh nghiên cứu, không phải kiểm kê số sản phẩm đang có trong một cơ sở dữ liệu triển khai.

Không tìm thấy trong luồng được khảo sát cơ chế thanh toán qua cổng ngân hàng, quản lý tồn kho định lượng, vận chuyển tích hợp nhà cung cấp hay cá nhân hóa bằng hồ sơ sở thích. Báo cáo không coi những nội dung này là chức năng đã hoàn thiện. Việc có các dependency liên quan trong `package.json` cũng không đủ chứng minh một thuật toán hoặc dịch vụ được gọi thực tế.

## 1.4. Phương pháp nghiên cứu

Phương pháp thứ nhất là phân tích tĩnh: đọc cấu trúc dự án, router, controller, middleware, Mongoose Model, dịch vụ và component; lần theo import và lời gọi từ trang chi tiết đến API và thuật toán. Phương pháp này xác định được các đường gọi và điều kiện trong mã, nhưng không tự xác nhận trạng thái của hệ thống production.

Phương pháp thứ hai là kiểm chứng bằng mã thực thi offline: sử dụng các hàm thuần để tái sinh dữ liệu từ seed, đối chiếu checksum, chạy ví dụ truy vấn và kiểm thử thuật toán. Kết quả mới được tách khỏi các benchmark đã lưu từ môi trường trước đó. Kiểm thử có model giả được phân biệt với kiểm thử MongoDB thật và kiểm thử trình duyệt.

Phương pháp thứ ba là đối chiếu học thuật với bản PDF *Data Mining: Concepts and Techniques*, ấn bản 3, có trong repository. Chương 6 của sách cung cấp nền tảng khai phá mẫu phổ biến và các độ đo; Chương 7 trình bày khai phá nâng cao, gồm đa cấp, ràng buộc và top-k giảm dư thừa. Các công thức do đồ án phối hợp thêm được ghi rõ nguồn gốc để tránh gán nhầm cho giáo trình.

## 1.5. Công nghệ sử dụng

| Thành phần | Công nghệ được khai báo | Vai trò |
|---|---|---|
| Shop | React ^18.2.0, React Router 6.4, Redux ^4.2.1, Axios ^1.4.0 | Duyệt hàng, tài khoản, giỏ hàng, gợi ý |
| Admin | React, các trang trong `Admin/Admin/src/pages` | Quản trị sản phẩm, đơn, tài khoản, coupon, bình luận |
| Backend | Node.js, Express ^4.18.2 | Router, kiểm tra dữ liệu, điều phối dịch vụ |
| Dữ liệu | Mongoose 6.10, MongoDB | Model và truy vấn tài liệu |
| Xác thực | bcrypt ^5.1.1, jsonwebtoken ^9.0.2 | Băm mật khẩu và JWT |
| Tệp ảnh | multer ^1.4.5-lts.1 | Tiếp nhận ảnh có kiểm tra loại và kích thước |
| Mining | JavaScript tự cài trong `services/mining` | Apriori, FP-Growth và sinh luật |

*Bảng 1.1. Công nghệ khai báo và vai trò trong hệ thống.*

Bảng thể hiện phiên bản khai báo, không khẳng định mọi máy triển khai đều cài đúng một phiên bản đó. Muốn tái lập môi trường cần dùng lockfile và ghi lại phiên bản runtime. Các thư viện `node-apriori` và `node-fpgrowth` xuất hiện trong dependency, nhưng luồng gợi ý hiện tại import thuật toán nội bộ qua `../mining`.

## 1.6. Kết quả dự kiến và đóng góp của đề tài

Kết quả phần mềm được nhận diện từ mã gồm hai ứng dụng giao diện và một API dùng chung, có phân quyền và nhiều quy tắc bảo toàn lịch sử đơn. Kết quả thuật toán là một module không phụ thuộc MongoDB, có đầu vào/đầu ra thống nhất cho Apriori và FP-Growth, cùng các độ đo luật. Kết quả kiến trúc là cơ chế cache snapshot, cache mô hình và phân biệt nguồn gợi ý để giao diện không trình bày fallback như một phát hiện đồng mua.

Đóng góp nghiên cứu ở mức vận dụng và thực nghiệm: mô hình hóa hierarchy từ cấu trúc Category–Product đang có; xác định những ràng buộc được phép cắt tỉa; khảo sát công thức xếp hạng và đa dạng hóa. Không có cơ sở để tuyên bố đề xuất một thuật toán khai phá hoàn toàn mới. Một đóng góp quan trọng của báo cáo là chỉ ra những giới hạn có thể ảnh hưởng việc bảo vệ đồ án: dữ liệu giả lập, tương thích dựa trên tên, toàn bộ trạng thái đơn cùng đi vào mining và chi phí khai phá đồng bộ.

## 1.7. Bố cục báo cáo

Chương 2 xây dựng ký hiệu, công thức và nền tảng thuật toán. Chương 3 mô tả yêu cầu và thiết kế suy ra từ mã. Chương 4 phân tích hiện thực website. Chương 5 trình bày luồng gợi ý cùng M1–M3 và ví dụ thực thi. Chương 6 phân biệt kiểm thử mới với kết quả đã lưu và đánh giá giới hạn. Chương 7 tổng hợp kết quả, đóng góp và hướng phát triển. Phụ lục cung cấp bản đồ mã nguồn, API và bằng chứng tái lập.

# CHƯƠNG 2. CƠ SỞ LÝ THUYẾT

## 2.1. Tổng quan thương mại điện tử

Trong phạm vi đồ án, thương mại điện tử là tổ chức quá trình trưng bày sản phẩm, tiếp nhận yêu cầu mua và quản lý trạng thái xử lý đơn qua giao diện web. Một sản phẩm có thông tin mô tả, giá, tình trạng và danh mục; một đơn lưu thông tin người nhận, các dòng hàng và số tiền tại thời điểm tạo. Giữ giá lịch sử của dòng hàng là yêu cầu quan trọng vì giá danh mục có thể đổi sau khi mua.

Cần phân biệt “tiếp nhận đơn” với “thanh toán thành công”. Trong TrungShop, API tạo một bản ghi đơn và trạng thái ban đầu `pending`; mã được khảo sát không chứng minh việc thu tiền qua cổng thanh toán. Tương tự, `is_stock` chỉ cho biết trạng thái còn hàng, chưa mô tả số lượng hàng để trừ theo từng đơn.

## 2.2. Hệ thống gợi ý sản phẩm

Một hệ gợi ý nhận ngữ cảnh và tạo danh sách đối tượng phù hợp. Với trang chi tiết TrungShop, ngữ cảnh mặc định chỉ là mã sản phẩm $p$ đang xem. Đầu ra là danh sách tối đa 5 sản phẩm khác $p$, có thể truy vết nguồn luật hoặc lý do fallback. Hệ thống không nhận lịch sử duyệt riêng của người dùng trong lời gọi `recommend(productId, query)`; vì vậy đây là gợi ý theo ngữ cảnh sản phẩm, không phải mô hình cá nhân hóa theo từng tài khoản.

Có thể biểu diễn bài toán là $R(p)=\operatorname{TopK}(\mathcal{C}(p))$, trong đó $\mathcal{C}(p)$ là tập ứng viên được sinh từ luật và dữ liệu danh mục. Chất lượng phụ thuộc đồng thời việc sinh ứng viên, thứ tự, lọc khả dụng và điền fallback. Một thuật toán khai phá tốt chưa bảo đảm danh sách cuối hữu ích nếu ứng viên chứa phụ kiện sai dòng máy hoặc fallback chiếm phần lớn kết quả.

## 2.3. Các phương pháp xây dựng hệ gợi ý

| Phương pháp | Dữ liệu thường cần | Đặc trưng | Quan hệ với TrungShop |
|---|---|---|---|
| Theo nội dung | Thuộc tính sản phẩm, sở thích | So khớp đặc trưng | Chưa thấy mô hình vector nội dung trong luồng mặc định |
| Lọc cộng tác | Tương tác người–sản phẩm | Học tương đồng/hành vi | Không dùng ma trận user–item trong API hiện tại |
| Luật kết hợp | Các giao dịch sản phẩm | Học quan hệ đồng xuất hiện, dễ giải thích | Là phương pháp đang tích hợp |
| Theo tri thức | Ràng buộc chuyên gia | Chọn theo điều kiện nghiệp vụ | M2 nghiên cứu; fallback có dùng tri thức khi ghép M2 |
| Phổ biến | Số đơn chứa sản phẩm | Đơn giản, dùng khi thiếu tín hiệu | Dùng để xếp fallback |

*Bảng 2.1. Phân loại phương pháp gợi ý và phạm vi hiện thực.*

Bảng là phân loại lý thuyết, không phải danh sách các thuật toán đều đã được xây dựng. Các phương pháp có thể kết hợp nhưng phải kiểm tra nguồn của mỗi mục đầu ra. Đặc biệt, gợi ý một ốp đúng dòng máy nhờ quy tắc tên có thể rất hữu ích dù không xuất phát từ luật kết hợp.

## 2.4. Khai phá dữ liệu

Khai phá dữ liệu tìm các mẫu có cấu trúc trong dữ liệu, là một bước trong quy trình gồm lựa chọn, làm sạch, biến đổi, khai phá và đánh giá. Trong bài toán này, chọn trường `items.prd_id` là bước lựa chọn; chuyển về chuỗi, loại trùng và sắp thứ tự là bước biến đổi; tìm tập phổ biến và sinh luật là khai phá; lọc lift, kiểm thử và đánh giá Top-K là đánh giá.

Chuẩn hóa có thể làm thay đổi ngữ nghĩa thống kê. Đếm mỗi sản phẩm một lần trong một đơn phù hợp với support theo giao dịch. Dùng `qty` làm số lần lặp lại sẽ biến bài toán thành đếm số lượng và không còn đúng với công thức support chuẩn. Mã TrungShop chủ động bỏ ảnh hưởng của `qty` trong mining.

## 2.5. Khai phá luật kết hợp

Gọi $I$ là tập mục, $D=\{T_1,\ldots,T_N\}$ là tập giao dịch với $T_i\subseteq I$. Luật $A\Rightarrow B$ có $A,B\subseteq I$, $A\ne\varnothing$, $B\ne\varnothing$ và $A\cap B=\varnothing$. Ký hiệu $n(X)=|\{T\in D:X\subseteq T\}|$ là số đếm hỗ trợ. Khi nói một giao dịch chứa $A\cup B$, giao dịch đó phải chứa tất cả mục của cả hai vế; dấu hợp ở đây là hợp tập mục, không phải phép “hoặc” giữa hai biến cố.

Quy trình chuẩn có hai bước: tìm tất cả tập mục có hỗ trợ đạt ngưỡng, sau đó chia mỗi tập phổ biến thành hai vế để tính confidence. Luật là quan hệ có hướng về xác suất có điều kiện; không phải mệnh đề logic đúng tuyệt đối. Confidence 80% không nói rằng 80% người dùng tương lai chắc chắn mua vế phải, vì phân bố có thể thay đổi.

## 2.6. Tập mục phổ biến – Frequent Itemset

Tập $X$ phổ biến nếu $n(X)\ge\theta$, với $\theta$ là ngưỡng số đếm. Khi ngưỡng tỷ lệ là $s\in(0,1)$, ta dùng $\theta=\lceil sN\rceil$. Trong `resolveMinSupportCount`, số thực nhỏ hơn 1 được hiểu là tỷ lệ; số nguyên từ 1 trở lên được hiểu là số đếm. Do đó truyền `minSupport=1` ở cấp module có nghĩa “ít nhất một đơn”, không phải “100% số đơn”. API gợi ý giới hạn riêng minSupport trong [0,002; 0,5] nên tránh sự nhập nhằng này ở giao diện HTTP.

Tính chất Apriori phát biểu: nếu $X$ phổ biến thì mọi tập con của $X$ cũng phổ biến; tương đương, tập chứa một tập con không phổ biến không thể phổ biến. Cơ sở là $X\subseteq Y\Rightarrow n(Y)\le n(X)$. Tính chất này đúng với một ngưỡng chung. Khi ngưỡng thay đổi theo cấp hoặc nhóm, việc kết luận phổ biến giữa các tập cần xét cả ngưỡng riêng, không chỉ support count.

## 2.7. Thuật toán Apriori

Apriori duyệt theo kích thước tập mục. Lần đầu đếm từng mục để tạo $L_1$. Với mức $k\ge2$, thuật toán nối các phần tử của $L_{k-1}$ có cùng tiền tố dài $k-2$ để tạo ứng viên, bỏ các ứng viên có tập con không nằm trong $L_{k-1}$, quét giao dịch để đếm và giữ ứng viên đạt ngưỡng. Khi mức mới rỗng, thuật toán dừng. TrungShop hiện thực các bước này bằng `findFrequent1Itemsets`, `aprioriGen`, `hasInfrequentSubset` và hàm nội bộ `countCandidates`.

Ví dụ sư phạm, không phải dữ liệu đo của cửa hàng: năm giao dịch lần lượt là $\{A,B\}$, $\{A,B,C\}$, $\{A,C\}$, $\{B,C\}$, $\{A,B\}$. Với $\theta=2$, ta có $L_1=\{A:4,B:4,C:3\}$. Ba cặp $AB,AC,BC$ có số đếm 3, 2, 2 nên đều phổ biến. Ứng viên $ABC$ được sinh vì mọi cặp con phổ biến nhưng chỉ xuất hiện một lần nên bị loại. Việc qua bước prune chỉ cho phép đếm, không bảo đảm ứng viên chắc chắn phổ biến.

Hiện thực TrungShop so sánh chi phí liệt kê các $k$-tập con của giao dịch với việc duyệt toàn bộ ứng viên. Giao dịch được thu gọn về các mục có trong ứng viên. Những điều chỉnh này giảm công việc thực tế mà không làm đổi định nghĩa support. Chi phí vẫn có thể tăng rất mạnh khi nhiều mục thường xuyên cùng xuất hiện; số tập con của một tập $m$ mục là $2^m$.

## 2.8. Thuật toán FP-Growth

FP-Growth nén các giao dịch vào cây tiền tố. Sau khi đếm hỗ trợ và bỏ mục không phổ biến, các mục trong mỗi giao dịch được xếp theo tần suất giảm dần rồi chèn vào FP-tree. Những giao dịch có tiền tố chung dùng chung nút. Header table lưu mỗi mục, tổng support và chuỗi node-link để truy cập tất cả nút mang mục đó.

Khai phá đi từ mục ít phổ biến trong header. Với một mục hậu tố $x$, conditional pattern base gồm các đường tiền tố dẫn đến $x$, có trọng số bằng số đếm ở nút $x$. Từ cơ sở này xây cây điều kiện rồi khai phá đệ quy. Nếu cây chỉ có một đường đi, sinh mọi tổ hợp trên đường đó; support của tổ hợp là số đếm nhỏ nhất trong các nút được chọn.

Với năm giao dịch ở mục 2.7, thứ tự ban đầu là $A,B,C$ khi hòa được xử lý ổn định. Cơ sở điều kiện của $C$ gồm đường $AB$ trọng số 1, đường $A$ trọng số 1 và đường $B$ trọng số 1. Từ đó suy ra $n(AC)=2$ và $n(BC)=2$, còn $n(ABC)=1$ bị loại. Kết quả phải trùng Apriori nếu cùng chuẩn hóa và ngưỡng. FP-Growth tránh sinh ứng viên kiểu Apriori nhưng không tránh được bùng nổ số lượng mẫu đầu ra; không thể kết luận luôn nhanh hơn trên mọi dữ liệu.

Trong mã, các khối tương ứng là `FPNode`, `buildFPTree`, `nodeLinks`, `conditionalPatternBase`, `singlePath` và `fpGrowth`. Mỗi giao dịch gốc có trọng số 1; cơ sở điều kiện có trọng số lớn hơn 1. Thứ tự hòa của cây con kế thừa thứ tự cây cha để kết quả có thể đối chiếu với ví dụ giáo trình.

## 2.9. Các độ đo đánh giá luật kết hợp

Dùng một ví dụ tính toán thống nhất, hoàn toàn mang tính minh họa: $N=10$, $n(A)=6$, $n(B)=5$ và $n(A\cup B)=4$. Các số này mô tả một bảng giao dịch giả định nhỏ nhằm giải thích công thức, không phải benchmark hoặc đơn hàng thật của TrungShop. Các mẫu số phải dương; một luật hợp lệ sinh từ tập phổ biến có cả hai vế xuất hiện nên đáp ứng điều kiện này.

### 2.9.1. Support

$$\operatorname{supp}(A\Rightarrow B)=\frac{n(A\cup B)}{N}. \tag{2.1}$$

$N$ là tổng số giao dịch, $n(A\cup B)$ là số giao dịch chứa đồng thời tất cả mục của hai vế. Ví dụ support bằng $4/10=0,4=40\%$. Support đo độ phổ biến toàn cục, không có hướng. Khi thêm nhiều giao dịch không chứa cả A lẫn B, support giảm dù quan hệ giữa A và B trong các giao dịch liên quan giữ nguyên.

### 2.9.2. Confidence

$$\operatorname{conf}(A\Rightarrow B)=\frac{n(A\cup B)}{n(A)}=P(B\mid A). \tag{2.2}$$

$n(A)$ là số giao dịch chứa A. Ví dụ confidence chiều $A\Rightarrow B$ là $4/6\approx0,6667$; chiều ngược là $4/5=0,8$. Confidence cao có thể chỉ phản ánh B vốn rất phổ biến, vì vậy cần so với $P(B)$ trước khi diễn giải quan hệ.

### 2.9.3. Lift

$$\operatorname{lift}(A,B)=\frac{\operatorname{supp}(A\cup B)}{\operatorname{supp}(A)\operatorname{supp}(B)}=\frac{n(A\cup B)N}{n(A)n(B)}. \tag{2.3}$$

Ví dụ lift là $4\times10/(6\times5)=1,3333$. Giá trị lớn hơn 1 cho thấy đồng xuất hiện nhiều hơn mức kỳ vọng độc lập; bằng 1 tương ứng độc lập theo các xác suất thực nghiệm; nhỏ hơn 1 là ít hơn kỳ vọng. Lift đối xứng và không có chặn trên cố định độc lập với support. Lift cao từ vài đơn rất hiếm có thể thiếu ổn định, vì thế không dùng riêng lift để tuyên bố chất lượng.

### 2.9.4. Kulczynski

$$\operatorname{Kulc}(A,B)=\frac12\left(\frac{n(A\cup B)}{n(A)}+\frac{n(A\cup B)}{n(B)}\right). \tag{2.4}$$

Ví dụ Kulc bằng $(0,6667+0,8)/2\approx0,7333$. Kulc là trung bình confidence hai chiều, nằm trong [0,1] khi dữ liệu hợp lệ. Kulc không phụ thuộc số giao dịch không chứa cả A lẫn B (null-invariant). Tuy nhiên cùng một Kulc có thể đi với mức chênh lệch tần suất hai mục khác nhau; IR giúp đọc thêm thông tin này.

### 2.9.5. Imbalance Ratio

$$\operatorname{IR}(A,B)=\frac{|n(A)-n(B)|}{n(A)+n(B)-n(A\cup B)}. \tag{2.5}$$

Mẫu số là số giao dịch chứa A hoặc B, còn tử số là độ chênh support count. Trong ví dụ, IR bằng $|6-5|/(6+5-4)=1/7\approx0,1429$. IR bằng 0 khi hai số đếm bằng nhau; IR cao cho biết hai mục có độ phổ biến mất cân bằng. IR không phải một phép đo trực tiếp “gợi ý sai” và không tự xác định ngưỡng loại luật.

### 2.9.6. So sánh và điều kiện diễn giải

Nếu giữ nguyên ba số đếm trên nhưng thêm 10 giao dịch không chứa A và B, $N$ tăng thành 20. Confidence, Kulc và IR không đổi; support còn 20% và lift tăng thành $8/3$. Ví dụ cho thấy lift nhạy với null-transactions. Không thể xem lift và Kulc như những thang điểm hoán đổi hoàn toàn; lựa chọn độ đo phải phù hợp mục tiêu và phân bố.

Trong TrungShop, `ruleMeasures(supAB, supA, supB, n)` trả đủ năm độ đo, nhưng phần xếp hạng mặc định chỉ dùng confidence, lift và support. Trường `support` trong itemset là số đếm, còn `support` trong rule là tỷ lệ; nhầm hai cấu trúc này có thể làm sai toàn bộ nhận xét về ngưỡng.

## 2.10. Khai phá luật kết hợp đa cấp độ

Một hierarchy mô tả quan hệ từ khái niệm tổng quát đến cụ thể. Ví dụ phù hợp schema TrungShop là gốc `all` → danh mục Samsung → sản phẩm Galaxy S24 FE. Không có trường danh mục cha trong model `category.js`, do đó không thể tự thêm một tầng “Điện thoại” vào thiết kế cơ sở dữ liệu đã có. Bộ tạo hierarchy hỗ trợ tổng quát nhiều cấp, nhưng phép ánh xạ danh mục thực tế của nghiên cứu sử dụng hai cấp có ý nghĩa.

Mở rộng giao dịch thêm các tổ tiên không gồm gốc. Nếu giao dịch chứa hai sản phẩm cùng danh mục, nút danh mục chỉ được tính một lần. Ngưỡng uniform dùng chung mọi cấp; reduced giảm ngưỡng ở cấp cụ thể; group cho phép ghi đè theo nhóm mục. Đối với tập trộn các nhóm, hiện thực dùng ngưỡng nhỏ nhất trong các mục tham gia, khai phá ở ngưỡng thấp nhất toàn cục rồi lọc theo ngưỡng riêng của tập.

Luật sản phẩm → chính danh mục cha có confidence 1 do định nghĩa taxonomy, không phải phát hiện hành vi mua kèm. Vì vậy phải bỏ tập chứa cặp tổ tiên–hậu duệ. Loại bỏ luật dư thừa do một luật tổng quát dự đoán được là vấn đề khác: cần so support/confidence với giá trị kỳ vọng. TrungShop có hàm `findRedundantRules` cho nghiên cứu nhưng không tự động gọi hàm này trong `mineMultilevel`.

## 2.11. Khai phá luật kết hợp dựa trên ràng buộc

Ràng buộc chống đơn điệu thỏa tính chất: một tập vi phạm thì mọi siêu tập của nó cũng vi phạm. Ví dụ $|S|\le2$ hoặc không chứa cặp xung đột; khi đã có ba mục hoặc một cặp xung đột, thêm mục không sửa được vi phạm. Có thể cắt nhánh trước khi đếm hoặc dựng cây điều kiện. Ràng buộc đơn điệu có chiều suy luận khác: nếu tập đã thỏa thì mọi siêu tập thỏa, ví dụ chứa ít nhất một mục thuộc V.

Ràng buộc succinct cho phép mô tả trực tiếp tập mục được phép trước khi đếm; chẳng hạn $S\subseteq V$ cho phép bỏ các mục ngoài V khỏi mọi giao dịch mà vẫn giữ số giao dịch gốc. Ràng buộc convertible như trung bình giá cần thứ tự đặc biệt để có tính chất đơn điệu; hiện thực nghiên cứu không tự triển khai chuyển đổi đó và chỉ hậu lọc. Tổng có thể âm cũng không được tùy tiện coi là chống đơn điệu.

Phân biệt ràng buộc tập với ràng buộc có hướng của luật: yêu cầu sản phẩm gợi ý còn hàng chỉ đặt lên vế phải, không buộc sản phẩm đang xem còn hàng. Đẩy điều kiện này thành “mọi mục trong tập phải còn hàng” sẽ làm mất cả luật có tiền đề hết hàng mà hệ thống vẫn có thể dùng để giới thiệu sản phẩm khác.

## 2.12. Xếp hạng và giảm trùng lặp kết quả gợi ý

Xếp hạng chọn thứ tự ứng viên theo độ liên quan. Giảm trùng lặp mã sản phẩm bằng Set khác với đa dạng danh mục: một danh sách có năm mã khác nhau vẫn có thể gồm năm điện thoại cùng loại. Mặc định TrungShop chỉ loại trùng mã, còn M3 nghiên cứu thêm phạt danh mục đã xuất hiện.

Hai công thức nghiên cứu là $\operatorname{Kulc}\,(1-\beta\operatorname{IR})$ và $\operatorname{conf}\,P(q)^{-\gamma}$. Công thức thứ hai bằng confidence khi $\gamma=0$ và bằng lift khi $\gamma=1$. Đây là cách phối hợp của đồ án; giáo trình cung cấp độ đo thành phần và thảo luận giảm dư thừa ở mức mẫu, không định nghĩa nguyên vẹn hai công thức này cho TrungShop.

Đa dạng hóa chọn tham lam ứng viên tối đa hóa $\lambda\operatorname{rel}(i)-(1-\lambda)\mathbf{1}[c(i)\text{ đã có}]$. Với $\operatorname{rel}(i)=1-\operatorname{rank}(i)/m$ và thứ hạng từ 0, công thức dùng độ liên quan dựa trên thứ hạng, không dùng trực tiếp thang điểm Kulc hoặc lift. Do đó bước đa dạng có thể đổi thứ tự theo cách khác việc trừ trực tiếp một hằng số khỏi điểm confidence.
