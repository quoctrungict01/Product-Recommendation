function Code(el)
  if FORMAT:match('latex') then
    local s = pandoc.write(pandoc.Pandoc({pandoc.Plain({el})}), 'latex')
    s = s:gsub('\\texttt', '\\codebreak', 1)
    return pandoc.RawInline('latex', s)
  end
end
