# CHƯƠNG 5. XÂY DỰNG HỆ THỐNG GỢI Ý SẢN PHẨM

## 5.1. Phát biểu bài toán gợi ý sản phẩm

Đầu vào online gồm mã sản phẩm đang xem $p$, thuật toán và ngưỡng tùy chọn. Đầu vào học gồm lịch sử orders và catalog products. Đầu ra là một danh sách không quá $K=5$ sản phẩm, không chứa $p$, không trùng ID, còn tồn tại và có `is_stock` khác false. Mỗi mục có nguồn `association-rule` hoặc `fallback`; mục từ luật có bằng chứng đồng xuất hiện, mục fallback có lý do riêng.

Mục tiêu của luồng mặc định là gợi ý theo quan hệ mua kèm của sản phẩm, không dự đoán toàn bộ giỏ trong tương lai hoặc cá nhân hóa người dùng. Tiền đề chỉ một sản phẩm là lựa chọn phù hợp với thông tin thực tế có ở trang chi tiết. Sinh và dùng luật nhiều tiền đề trong bối cảnh này sẽ đòi hỏi giả định thêm về các sản phẩm khác mà khách đã chọn; hiện thực chủ động không làm như vậy.

| Tầng | Câu hỏi giải quyết | Hiện thực |
|---|---|---|
| Dữ liệu | Những mục nào cùng nằm trong một đơn? | `transactionsFromOrders` |
| Khai phá | Tập nào xuất hiện đủ nhiều? | `apriori` hoặc `fpGrowth` |
| Luật | Quan hệ có hướng nào đạt confidence? | `generateRules` |
| Ứng viên | Luật nào phù hợp p đang xem? | `indexSingleItemRules` |
| Xếp hạng/lọc | Sản phẩm nào ưu tiên và còn bán? | `rankRecommendations` |
| Dự phòng | Thiếu luật thì điền gì? | Cùng danh mục rồi độ phổ biến |
| Trình bày | Mục nào thực sự có nguồn luật? | `FrequentlyBoughtTogether` |

*Bảng 5.1. Phân rã bài toán theo các khối được gọi trong mã.*

## 5.2. Dữ liệu đầu vào

`createModelLoaders` nhận OrderModel và ProductModel qua tham số. `loadOrders` dùng `find({}, {"items.prd_id":1}).lean().exec()`, không lọc status và không lấy danh tính người mua. Việc không lấy thông tin cá nhân là đủ cho thuật toán giao dịch; nó cũng xác nhận hệ thống không cần hồ sơ sở thích cá nhân để sinh luật.

`loadProducts` lấy name, image, price, category_id và is_stock mỗi request. Các trường này phục vụ kiểm tra khả dụng, hiển thị và fallback; nội dung chi tiết sản phẩm không tham gia khai phá một cấp. Controller đọc thêm price, promotion và is_stock để gắn giá hiển thị qua `attachPricing`.

Fingerprint là chuỗi số đơn và `_id` lớn nhất: `${count}:${latestId}`. Nó rẻ hơn đọc toàn bộ item của tất cả đơn, nhưng không bao phủ mọi thay đổi. Sửa items của một đơn mà giữ nguyên số lượng đơn và ID lớn nhất không làm đổi fingerprint; TTL hoặc invalidate thủ công mới buộc học lại trong trường hợp đó. Đọc đơn và đọc fingerprint được gọi đồng thời cũng không tạo một snapshot transaction nhất quán ở DB.

## 5.3. Tiền xử lý dữ liệu đơn hàng

`transactionsFromOrders` kiểm tra đầu vào là mảng, ánh xạ mỗi order sang `items.map(item=>item?.prd_id)`, dùng mảng rỗng nếu items thiếu. `normalizeItem` bỏ null/undefined và chuỗi rỗng sau trim; các mục còn lại chuyển bằng String, cho phép ObjectId được sử dụng trực tiếp thông qua toString. `normalizeTransactions` dùng Set để loại trùng và sort để có thứ tự từ điển ổn định.

Đơn rỗng vẫn là một giao dịch và vẫn tham gia mẫu số $N$. Đây là lựa chọn tường minh trong mã. Nếu dữ liệu bẩn sinh nhiều đơn rỗng, support của mọi sản phẩm giảm; việc tự bỏ đơn rỗng trong báo cáo mà không đổi mã sẽ mô tả sai thuật toán thực tế. Tương tự, không tự lọc đơn cancelled hoặc chỉ giữ delivered khi mã loader hiện đọc tất cả.

Ví dụ minh họa cấu trúc: một đơn có ba dòng `(p, qty=2)`, `(p, qty=1)`, `(q, qty=3)` thành giao dịch `{p,q}`. Support của p và q tăng một đơn, không tăng theo tổng qty. Nếu một order không có mảng items thì giao dịch là `{}`. Ví dụ này giải thích phép biến đổi, không phải trích một đơn khách hàng thật.

## 5.4. Biểu diễn giao dịch

Sau chuẩn hóa, dữ liệu là mảng các mảng chuỗi đã sắp. Một itemset được biểu diễn `{items: [...], support: count}`. Hàm `itemsetKey` chuẩn hóa khóa để lập Map tra support; `sortItemsets` tạo thứ tự đầu ra ổn định. Số đếm là số giao dịch chứa tập, không phải tổng số lần mục xuất hiện ở các dòng.

Bất biến cần giữ là mọi item trong một giao dịch xuất hiện nhiều nhất một lần, và mọi itemset có thứ tự chuẩn. Bước join Apriori dựa vào tiền tố nên thứ tự không chỉ phục vụ dễ đọc. FP-tree dùng thứ tự theo tần suất riêng trong quá trình dựng cây, nhưng đầu ra được sắp lại trước trả kết quả để đối chiếu với Apriori.

Hợp đồng vào/ra thuần JavaScript giúp test không cần MongoDB. Khi đưa dataset nghiên cứu vào module, `history.map(o=>o.items)` đã có dạng giao dịch; không truyền trực tiếp order nghiên cứu cho `transactionsFromOrders` vì định dạng nghiên cứu dùng items là các chuỗi, còn order website dùng các object có prd_id.

## 5.5. Khai phá tập phổ biến

`mine` chọn hàm từ bảng ALGORITHMS theo tên; mặc định là fpgrowth. Hai thuật toán đều chuẩn hóa đầu vào và dùng chung `resolveMinSupportCount`. Đầu ra gồm itemsets và stats, trong đó Apriori thống kê các mức/candidate, FP-Growth thống kê nút cây, cây điều kiện, single-path shortcut và độ sâu. Những trường stats phục vụ giải thích cấu trúc tính toán; không đồng nhất chúng với thời gian toàn bộ request API.

Ví dụ ở lịch sử 16.000 đơn và minSupport=0,002, số đếm tối thiểu là 32. Một cặp xuất hiện 31 đơn bị loại dù mỗi sản phẩm riêng lẻ có nhiều đơn. Ngược lại, một cặp có 32 đơn có thể tạo luật nhưng vẫn không được gợi ý nếu lift không lớn hơn 1, confidence không đạt ngưỡng hoặc sản phẩm không còn khả dụng.

Ngưỡng thấp tăng số tập và số luật, có thể giúp recall nhưng tăng chi phí và nhiễu. Ngưỡng cao làm mô hình nhỏ, nhưng dễ bỏ quan hệ của sản phẩm ít giao dịch. Đây là động lực của nghiên cứu M1, đồng thời giải thích vì sao so mô hình mở rộng với baseline dùng ngưỡng mặc định mà không có baseline đã chọn ngưỡng sẽ gây kết luận sai về đóng góp thuật toán.

## 5.6. Sinh luật kết hợp

`generateRules` duyệt các itemset dài ít nhất 2. Với mỗi tập phổ biến $L$ kích thước $m$, duyệt $2^m-2$ tập con thực sự khác rỗng để tạo tiền đề $A$ và hậu đề $L\setminus A$. Tra support của cả hai vế trong Map, tính `ruleMeasures`, giữ luật đạt minConfidence với dung sai $10^{-12}$. Kết quả được sắp confidence rồi lift, sau đó thứ tự tập mục để ổn định.

Nếu danh sách itemsets thiếu support của một tập con cần thiết, hàm ném lỗi thay vì dùng 0 hoặc suy đoán. Tính đầy đủ của tập phổ biến là tiền điều kiện quan trọng. Các bước lọc itemset nâng cao phải giữ hoặc cung cấp các support cần thiết trước khi sinh luật; lọc mọi singleton thấp ngưỡng riêng quá sớm trong M1 có thể làm hỏng điều kiện này.

Hàm dùng bitmask `1 << n` và từ chối itemset dài hơn 30. Giới hạn 30 bảo vệ biểu diễn bitwise, chưa phải bảo đảm hiệu năng: $2^{30}-2$ trường hợp vẫn quá lớn trong thực tế. Luồng mặc định khai phá và sinh mọi luật trước khi chỉ mục 1→1 loại phần không dùng; hướng tối ưu là giới hạn sinh luật cần thiết, như các mô hình offline đã làm với `maxRuleItemsetSize=2`.

## 5.7. Các chỉ số đánh giá luật trong hiện thực

`ruleMeasures` trả `support`, `supportCount`, `confidence`, `lift`, `kulczynski` và `imbalanceRatio`. Công thức đúng theo mục 2.9 khi số đếm đầu vào hợp lệ. Hàm tự nó không là một bộ xác minh bảng xác suất: lời gọi thủ công với supAB lớn hơn supA/supB hoặc mẫu số 0 có thể tạo giá trị vô nghĩa. Trong quy trình chuẩn, các số đếm lấy từ tập phổ biến đầy đủ nên quan hệ đếm được bảo đảm bởi miner.

`indexSingleItemRules` chỉ đưa luật có antecedent.length=1 và consequent.length=1 vào chỉ mục theo productId. `rankRecommendations` dùng điều kiện `rule.lift > minLift`, mặc định minLift=1, nghĩa là lift đúng 1 bị loại. Không có tham số minLift công khai trong `parseOptions`; không nên liệt kê nó như query HTTP được hỗ trợ mặc định.

Sau sắp xếp, thuật toán bỏ chính sản phẩm xem, sản phẩm trùng, không tìm thấy và hết hàng, đồng thời đếm skipped theo nhóm. `matchedRuleCount` là số luật khớp tiền đề trước khi lọc và cắt limit, không phải số sản phẩm cuối được hiển thị. Việc diễn giải metadata đúng giúp tránh nhận xét “API trả 100 gợi ý” chỉ vì matchedRuleCount bằng 100.

## 5.8. Kiến trúc module mining và recommendation

| Module/hàm | Đầu vào | Đầu ra | Trách nhiệm |
|---|---|---|---|
| `transactionsFromOrders` | Order `items[{prd_id}]` | Mảng giao dịch | Chuẩn hóa, loại trùng |
| `apriori`, `fpGrowth` | Giao dịch và minSupport | itemsets, stats | Đếm tập phổ biến |
| `generateRules` | itemsets, N, minConfidence | Danh sách luật | Sinh hai vế và độ đo |
| `createModelLoaders` | Model Mongoose | Ba loader | Tách DB khỏi thuật toán |
| `createRecommendationService` | Loader và cấu hình cache | recommend/status/invalidate/getModel | Điều phối và cache |
| `rankRecommendations` | p, ruleIndex, catalog, itemCounts | items, skipped, matchedRuleCount | Chọn, lọc và fallback |
| `attachPricing` | Dữ liệu gợi ý, loader giá | Dữ liệu có giá bán | Bổ sung thông tin hiển thị |

*Bảng 5.2. Hợp đồng của các khối chính trong luồng tích hợp.*

Snapshot gồm transactions, itemCounts, fingerprint, loadedAt và version. Mô hình có khóa version|algorithm|minSupport|minConfidence. Limit không nằm trong khóa vì nó chỉ ảnh hưởng cắt danh sách, không thay đổi tập luật. Snapshot dùng chung cho hai thuật toán; mỗi cấu hình mining dùng mô hình riêng. TTL mặc định là 10 phút, khoảng kiểm fingerprint 30 giây.

Các request cùng chờ snapshotPromise hoặc promise của một mô hình để tránh lặp tải/khai phá cho cùng khóa. Tuy nhiên mining thực hiện đồng bộ trên CPU; Promise chỉ điều phối kết quả, không tạo worker thread. Số tổ hợp ngưỡng là số thực nên Map mô hình có thể tăng nếu nhiều request chọn các ngưỡng khác nhau trong khoảng hợp lệ; không thấy một mức trần số model trong cache.

`invalidate` xóa snapshot và models, ghi lý do. Nó không hủy promise snapshot đang chạy. Một tải cũ có thể hoàn tất sau invalidate và gán lại snapshot trong điều kiện cạnh tranh; đây là khả năng từ hiện thực, cần kiểm chứng bằng test race trước khi đưa ra cam kết “refresh luôn lập tức thay mọi dữ liệu đang tải”. Tương tự, nhiều instance Node có cache độc lập và không tự lan truyền invalidate.

Fallback xây pool còn hàng chưa chọn. Danh sách cùng danh mục được sắp theo số đơn chứa sản phẩm; tiếp theo danh sách bán chạy toàn catalog cũng sắp theo số đơn. Dùng Set tránh đưa lại cùng sản phẩm ở hai lượt. “Bán chạy” ở đây là số đơn có sản phẩm sau loại trùng, không phải số đơn vị bán, doanh thu hoặc lượt nhấp.

## 5.9. M1 – Khai phá luật kết hợp đa cấp độ

### 5.9.1. Hierarchy và quan hệ sản phẩm–danh mục

`hierarchyFromCatalog` tạo ID có tiền tố `C:` cho danh mục và `P:` cho sản phẩm. Gốc `all` không là item vì xuất hiện trong mọi giao dịch sẽ tạo các luật hiển nhiên. Hàm kiểm tra product trùng ID, category_id thiếu; `createHierarchy` kiểm tra nút cha tồn tại, ID trùng và chu trình. Những kiểm tra này cần thiết vì một hierarchy sai làm sai support mở rộng hoặc gây duyệt vô hạn.

`extendTransactions` thêm tổ tiên rồi Set để loại trùng. `generalizeTransactions` thay mục bằng tổ tiên tại một cấp cho cách khai phá theo từng mức. Đồ án không tạo tầng danh mục cha không có trong DB. Danh mục điện thoại và phụ kiện dùng trong M2 là phân loại tri thức theo tên, không phải một collection taxonomy ba tầng được thêm vào schema.

![Hình 5.1. Nguyên tắc mở rộng giao dịch M1 từ quan hệ category_id.](hinh_anh_so_do/hierarchy.png)

### 5.9.2. Support và khai phá theo cấp

`resolveThresholds` hỗ trợ uniform, reduced và group. Reduced yêu cầu ngưỡng cấp sâu không lớn hơn cấp trước; group cấm một item thuộc nhiều nhóm ghi đè và kiểm tra item có trong hierarchy. Ngưỡng mỗi item là ngưỡng nhóm nếu có, nếu không là ngưỡng cấp. Với tập S:

$$s_{\min}(S)=\min_{x\in S}s_{\min}(x),\qquad \theta(S)=\lceil Ns_{\min}(S)\rceil. \tag{5.1}$$

Đặt $s_*=\min_xs_{\min}(x)$. `mineMultilevel` khai phá toàn bộ giao dịch mở rộng tại $s_*$, bỏ tập tổ tiên–hậu duệ, sau đó giữ tập đạt ngưỡng riêng. Vì ngưỡng riêng không thấp hơn $s_*$, mọi tập cần giữ đều có trong kết quả khai phá gốc. Để sinh luật, code dùng danh sách nonTrivial còn đầy đủ support tập con, rồi chỉ giữ luật có hợp hai vế đạt ngưỡng riêng. Đây là điểm quyết định tránh sai logic đóng theo tập con khi dùng ngưỡng khác nhau.

Luật được gắn type `level-1`, `level-2` hoặc `mixed`. `mineLevelByLevel` là cách đối chiếu thuần từng cấp với uniform/reduced, có cắt theo tổ tiên phổ biến khi uniform. Nó không trả đầy đủ các luật mixed của `mineMultilevel`; không so hai danh sách mà bỏ qua khác biệt phạm vi.

### 5.9.3. Loại luật tầm thường và phát hiện dư thừa

`containsAncestorPair` loại mọi itemset có cả mục và tổ tiên, nên luật p→cha(p) và chiều ngược từ cùng cặp không xuất hiện. Đây là loại theo ngữ nghĩa taxonomy. Hàm `findRedundantRules` lại xét một luật cụ thể và luật tổ tiên có trong tập luật, ước lượng support/confidence kỳ vọng bằng tỷ lệ support của các mục được thay.

Với luật tổng quát $r_g$ và luật cụ thể $r_s$, hiện thực dùng:

$$E[s(r_s)]=s(r_g)\prod_{x\to z}\frac{n(x)}{n(z)},\quad E[c(r_s)]=c(r_g)\prod_{x\to z\;\text{ở vế phải}}\frac{n(x)}{n(z)}. \tag{5.2}$$

Luật được đánh dấu dư thừa nếu cả support và confidence gần kỳ vọng trong tolerance mặc định 0,1. Code giới hạn `maxAncestorCombos=4096`. Công thức tích nhiều phép thay là cách hiện thực mở rộng ý tưởng so kỳ vọng; không phải khẳng định các tỷ lệ phản ánh độc lập thống kê thật. Đặc biệt, factory gợi ý M1 không tự gọi `findRedundantRules`; không viết rằng mọi luật dư thừa kiểu kỳ vọng đã bị loại trong danh sách gợi ý.

### 5.9.4. Ánh xạ luật danh mục về sản phẩm

M1 sử dụng tiền đề là p hoặc danh mục C của p, hậu đề là sản phẩm q hoặc danh mục D. Bốn dạng là p→q, p→D, C→q và C→D. Với hậu đề D, các sản phẩm con được cho trọng số theo bằng chứng đồng xuất hiện:

$$\begin{aligned}w(q\mid X,D)&=\frac{n(X\cup\{q\})}{n(X\cup\{D\})},\\score(q)&=conf(X\Rightarrow D)\,w(q\mid X,D).\end{aligned} \tag{5.3}$$

Các số đếm được lấy từ các tập phổ biến đã khai phá, không quét lịch sử tùy ý để bổ sung. Nếu thiếu cặp X,q, `weight` lùi X lên cha; nếu vẫn không có bằng chứng thì w=0. Khi các số đếm dùng cùng X và đều có, tích bằng n(X,q)/n(X), tức confidence của luật cụ thể. Khi lùi ngữ cảnh để ước lượng w nhưng vẫn nhân confidence của luật nguồn ban đầu, không được tự diễn giải kết quả như một xác suất có điều kiện được đo trực tiếp cho riêng sản phẩm hiếm.

Policy `specific-first` ưu tiên số nút sản phẩm trong luật rồi score, lift, support và ID. Policy `score` đặt score trước specificity. Mỗi sản phẩm chỉ giữ ứng viên tốt nhất theo comparator; sau đó lọc khả dụng, áp candidateFilter nếu được ghép M2 và điền fallback nếu bật. Cơ chế lùi cấp giúp tăng cơ hội có bằng chứng, nhưng quan hệ của danh mục không nhất thiết đúng với mọi sản phẩm con.

### 5.9.5. Ví dụ kiểm thử nhỏ có thể tái hiện

Fixture trong `test/multilevel/recommender-evaluation.test.js` gồm 200 giao dịch: 60 lần {s1,c1}, 50 lần {s2,c2}, 20 lần {s1,ch1}, 20 lần {s2,ch1}, 2 lần {sR,ch1}, 1 lần {sR,cR}, 10 lần {s1,c3} và 37 lần {x1}. Danh mục S chứa s1,s2,sR; K chứa c1,c2,cR,c3; H chứa ch1; c3 hết hàng. Đây là fixture kiểm thử mang tính minh họa của repository, không phải dữ liệu khách hàng.

Với support 0,05, ngưỡng là 10. sR chỉ có 3 đơn nên không tạo luật một cấp. Ở cấp danh mục, S có 163 đơn; c1 có 60 đơn cùng S, c2 có 50, ch1 có 42. M1 ở chế độ rules-only, specific-first trả c1,c2,ch1 cho sR; c3 bị bỏ vì hết hàng, cR thiếu bằng chứng. Ví dụ này chứng minh cơ chế dùng luật danh mục, không chứng minh ba gợi ý đều phù hợp nghiệp vụ cho mọi sản phẩm của S.

Đối với s1, số đơn là 90. Luật s1→K có confidence 70/90; ánh xạ về c1 có w=60/70, cho score=60/90. Kết quả bằng confidence s1→c1. Đây là một phép kiểm tra nhất quán của ánh xạ khi có đủ support cụ thể; dữ liệu và phép tính đều có trong fixture test.

### 5.9.6. Ví dụ từ danh mục TrungShop và giới hạn

Lần chạy minh họa mới dùng R1b, seed 20261101, 20.000 đơn; chỉ lấy train∪validation 16.000 đơn. Ngưỡng sản phẩm 0,002, danh mục 0,005, confidence 0, policy specific-first. Đây là cấu hình minh họa được ghi rõ, không phải tuyên bố cấu hình tối ưu đã chọn trong benchmark cũ. Galaxy S24 FE có 51 đơn lịch sử; luật một cấp ở cấu hình này không có gợi ý đạt điều kiện, nên danh sách mặc định chỉ có fallback.

M1 trả lần lượt: Củ sạc nhanh Samsung 45W (score 0,144024), Ốp lưng Galaxy S24 Ultra (0,124966), Kính cường lực Galaxy S24 Ultra (0,089573), Tai nghe có dây Samsung IA500 (0,087122) và Ốp lưng trong suốt iPhone 14 series (0,024231), đều có nhãn association-rule qua ngữ cảnh phân cấp. Kết quả cho thấy M1 phục hồi được một gợi ý sạc nhưng đồng thời mang theo gợi ý ốp/kính khác dòng máy. Không thể kết luận “đa cấp luôn cải thiện chất lượng” chỉ vì có nhiều luật hơn.

Ưu điểm của M1 là tận dụng quan hệ nhóm khi mục cụ thể ít giao dịch và giữ được nguồn luật. Hạn chế là giao dịch mở rộng dài hơn, số tập tăng, ngưỡng nhiều hơn, quan hệ tổng quát có thể thiếu phù hợp ở cấp sản phẩm và không tự có tri thức phần cứng. M1 chưa được tích hợp vào website; các kết quả này chỉ là thực thi offline.

## 5.10. M2 – Khai phá dựa trên ràng buộc

### 5.10.1. Ràng buộc nghiệp vụ và dữ liệu sử dụng

`buildBusinessRules` phân loại phone theo tên category trong danh sách iPhone, Samsung, Xiaomi, OPPO, Vivo, Nokia; các category khác được coi là accessory. Cần truyền thêm `category` là tên danh mục trong catalog nghiên cứu. Chỉ có category_id mà thiếu tên sẽ không đủ để cách phân loại này nhận diện đúng điện thoại; đây là điều kiện cần nếu sau này tích hợp vào API đang dùng loader sản phẩm khác định dạng.

`modelOf` nhận diện ốp lưng/kính cường lực ở đầu tên, bỏ một số từ silicon/trong suốt và đuôi series, rồi chuyển về chữ thường. Phụ kiện không khớp mẫu được coi là dùng chung. `fits` dùng phép includes giữa tên điện thoại và tên dòng máy đã rút ra. Đây là heuristic văn bản: “sạc, cáp, tai nghe, pin dùng chung” là giả định của mô hình, không phải chứng nhận tương thích công suất, cổng kết nối, giao thức hay kích thước.

| Mã | Ràng buộc | Nơi áp dụng |
|---|---|---|
| A1 | Một sản phẩm → một sản phẩm | Chọn luật/ứng viên |
| A2 | Nếu tiền đề là điện thoại thì hậu đề là phụ kiện | Lọc cặp có hướng |
| A3 | Cặp phù hợp heuristic tên dòng máy | Lọc luật và fallback |
| A4 | Sản phẩm gợi ý còn hàng | Chỉ hậu đề |
| B1 | count(S) ≤ 2 | Cắt tỉa tập mục |
| B2 | count(S ∩ điện thoại) ≤ 1 | Cắt tỉa tập mục |
| B3 | Không có cặp không tương thích | Cắt tỉa tập mục |

*Bảng 5.3. Ràng buộc M2-A và M2-B trong `business.js`.*

B2 cần được hiểu trong mục tiêu nghiên cứu mua kèm phụ kiện: cặp hai điện thoại bị bỏ, dù chúng có thể cùng nằm trong một đơn hợp lệ. M2 không phải luật xác thực đơn hàng và không từ chối khách mua hai điện thoại; nó giới hạn không gian mẫu/ứng viên gợi ý theo mục tiêu đã chọn.

### 5.10.2. Push và post trong Apriori, FP-Growth

`constrainedApriori` dùng chung các khối `findFrequent1Itemsets` và `aprioriGen`, lọc ứng viên vi phạm trước đếm. Vì vi phạm chống đơn điệu, việc bỏ ứng viên cũng ngăn sinh mọi siêu tập từ nó ở mức sau mà không mất mẫu thỏa. Các số generated, prunedByConstraint và counted được ghi riêng để giải thích chi phí.

`constrainedFPGrowth` kiểm tra mẫu beta trước xuất và trước dựng cây điều kiện; trong conditional pattern base, mục x bị bỏ nếu beta∪{x} vi phạm. Single-path shortcut cũng kiểm tra ràng buộc cho từng mở rộng. Tính an toàn dựa vào ràng buộc chống đơn điệu, không phải vì mọi điều kiện kinh doanh đều có thể đẩy vào cây.

`assertPushable` từ chối constraint không có tính chất phù hợp. `postFilter` là lọc sau khai phá gốc. Với cùng các ràng buộc chống đơn điệu, hai chế độ phải giữ cùng các itemset và support, nhưng thời gian có thể khác. Ràng buộc hậu lọc không chống đơn điệu có thể làm danh sách không còn đóng theo tập con; không truyền tùy tiện kết quả đó vào `generateRules` mà thiếu support cần thiết.

Đối với tồn kho A4, code chỉ lọc hậu đề và fallback, không đẩy thành “mọi mục còn hàng”. Nếu p hết hàng nhưng q còn hàng, hệ thống vẫn có thể gợi ý q. Đây là ví dụ cụ thể vì sao phải phân biệt điều kiện của một tập vô hướng với điều kiện của hai vế luật có hướng.

### 5.10.3. Ví dụ xử lý và kết quả

Ví dụ nghiệp vụ dựa trên tên trong catalog: tiền đề là Samsung Galaxy S24 FE 128GB. Một ứng viên Samsung Galaxy S24 Ultra là điện thoại nên vi phạm A2. Ốp lưng Galaxy S24 Ultra vi phạm A3 vì tên dòng máy không nằm trong tên điện thoại đang xem. Củ sạc nhanh Samsung 45W không có model-specific nên qua heuristic A3 nếu còn hàng; điều này không chứng minh sạc được kiểm nghiệm kỹ thuật trên máy.

Trong lần chạy R1b minh họa mục 5.9, M2 một cấp với support 0,002/confidence 0 không tạo gợi ý từ luật cho Galaxy S24 FE. Sau lọc fallback, danh sách là Củ sạc nhanh USB-C 20W, Pin dự phòng Xiaomi 10.000mAh 20W, Tai nghe Apple AirPods 2, Pin dự phòng Samsung 20.000mAh 45W và Cáp Apple USB-C to USB-C 1m. Cả năm đều mang source fallback. Việc danh sách không chứa điện thoại không đồng nghĩa có năm luật mới; đây là tác động của tri thức lọc và thứ tự phổ biến.

Với Apriori, ứng viên {Galaxy S24 FE, Galaxy S24 Ultra} có hai phone nên B2 loại trước đếm; tập {Galaxy S24 FE, Ốp Galaxy S24 Ultra} bị B3 loại. Với post, các ứng viên này vẫn có thể được đếm rồi mới bỏ. Các cặp thỏa còn lại phải có support giống nhau giữa hai cách. Chương 6 trình bày kết quả benchmark lưu trong repository, gồm cả trường hợp push FP-Growth chậm hơn post.

### 5.10.4. Ưu điểm và hạn chế

M2 giúp kiểm soát danh sách theo mục tiêu phụ kiện, giảm mẫu không cần thiết và cung cấp lý do vi phạm. Có thể ghép M1 thông qua constraintsFor và candidateFilter/fallbackFilter. Nhưng tính đúng của tên category và tên model là tiền điều kiện; các từ viết tắt, tên thiếu, khác cách đặt hoặc dòng máy có tên chứa nhau có thể gây bỏ sót/nhận nhầm.

Tỷ lệ hợp lý nghiệp vụ 100% trên các bảng nghiên cứu có nghĩa mọi mục thỏa chính bộ kiểm tra A2–A4. Nó không là độ chính xác được chuyên gia phần cứng độc lập chấm, không là mức hài lòng khách hàng và không xác nhận tính đầy đủ của taxonomy. M2-B có thể giảm công việc khai phá nhưng có overhead kiểm ràng buộc; ít mẫu hơn không bảo đảm luôn chạy nhanh hơn.

## 5.11. M3 – Xếp hạng và đa dạng hóa kết quả

### 5.11.1. Nguồn ứng viên và chiến lược

`fitBase` hỗ trợ flat, m2-flat, m1 và m2-m1. `flatCandidateFn` tạo ứng viên từ luật một cấp; `multilevelCandidateFn` nhận ứng viên từ M1 và xây các đại lượng cần tính độ đo. `buildRanked` dùng cùng nguồn ứng viên nền, đổi thứ tự rồi chọn Top-K. Chiến lược native giữ thứ tự gốc và được kiểm tra đối chiếu; khác biệt chất lượng khi dùng chiến lược khác cần quy cho thứ tự/chọn danh sách, không cho một lần khai phá dữ liệu mới.

Các đại lượng của ứng viên là joint, supX, supQ và N. Với luật cụ thể joint là số đếm thật. Với ứng viên phân cấp có ánh xạ, joint được ước lượng bằng score M1 × supX. Khi đó Kulc/IR tính từ ứng viên phân cấp có thể dùng đại lượng ước lượng, không mặc định xem là bảng đếm quan sát trực tiếp của cặp p,q.

| Strategy | Điểm | Vai trò tham số |
|---|---|---|
| native | Giữ thứ tự nền | Không tạo một thang điểm mới |
| confidence | joint/supX | Ưu tiên xác suất có điều kiện |
| kulc-ir | Kulc × (1 − β IR) | β tăng mức phạt mất cân bằng |
| popularity | confidence × popularity^(−γ) | γ tăng ưu tiên tương đối cho mục ít phổ biến |

*Bảng 5.4. Chiến lược `scoreOf` và `rankCandidates`.*

Nếu hòa điểm trong dung sai, comparator dùng lift, jointCount, nativeRank rồi ID. Giữ thứ tự ổn định quan trọng cho tái lập: một thay đổi trong thứ tự hòa có thể làm thay mục thứ 5 và ảnh hưởng hit/coverage dù điểm chính bằng nhau.

### 5.11.2. Công thức và nguồn gốc

$$score_{KI}(X,q)=Kulc(X,q)\,[1-\beta IR(X,q)]. \tag{5.4}$$

$$pop(q)=\frac{n(q)}{N},\qquad score_{pop}(X,q)=conf(X\Rightarrow q)\,pop(q)^{-\gamma}. \tag{5.5}$$

Kulc và IR là độ đo nền trong mục 6.3.3 của sách. Phép nhân phạt ở (5.4) là lựa chọn của đồ án; beta được chọn trên validation, không là tham số do giáo trình quy định. Công thức (5.5) nội suy confidence–lift ở gamma từ 0 đến 1; ở gamma=1 chính là lift. Dữ liệu cho ứng viên hợp lệ cần pop>0 để tránh lũy thừa âm tại 0.

Với ví dụ N=10, n(X)=6, n(q)=5, joint=4 ở Chương 2, $\beta=0,5$ cho $score_{KI}\approx0,733333\times(1-0,5/7)=0,680952$. Với $\gamma=0,5$, $score_{pop}\approx0,942809$; với $\gamma=1$, điểm bằng $1,333333$, đúng lift. Đây là ví dụ toán học minh họa công thức, không phải số đo thực nghiệm trên đơn TrungShop.

### 5.11.3. Đa dạng hóa theo danh mục

Với m ứng viên đã xếp, code dùng thứ hạng r từ 0. Ở mỗi lượt chọn:

$$i^*=\arg\max_{i\notin S}\left\{\lambda\left(1-\frac{r_i}{m}\right)-(1-\lambda)\mathbf1[c(i)\in c(S)]\right\}. \tag{5.6}$$

$S$ là danh sách đã chọn, $c(i)$ là danh mục, lambda trong [0,1]. Lambda=1 giữ nguyên thứ tự; lambda nhỏ hơn khuyến khích danh mục mới. Hòa được giải bằng thứ tự ban đầu. Mức phạt chỉ là nhị phân “đã có hay chưa”, không tăng theo số lần lặp danh mục và không đo tương đồng nội dung giữa các sản phẩm.

Ví dụ sư phạm với thứ tự A1,A2,B1 và m=3, A1/A2 cùng danh mục A, B1 thuộc B, lambda=0,5: chọn A1 trước; ở lượt sau A2 có giá trị 0,5×(2/3)−0,5=−1/6, B1 có 0,5×(1/3)=1/6, nên chọn B1 rồi A2. Kết quả A1,B1,A2 là tác động của phạt danh mục, dù A2 vốn xếp trên B1.

Trong `buildRanked`, luật luôn được chọn trước fallback. Nếu còn chỗ, fallback cũng được đa dạng hóa và biết danh mục đã có ở phần luật. Vì vậy mô tả M3 chỉ đa dạng hóa các luật là thiếu; phần fallback có thể thay đổi đáng kể và tạo hiệu quả trên truy vấn không có luật nào.

### 5.11.4. Ví dụ chạy trên dữ liệu TrungShop

Với lịch sử R1b minh họa, iPhone 15 128GB có 1.146 đơn. Luật một cấp xếp Ốp lưng silicon iPhone 15, Kính cường lực iPhone 15, Củ sạc nhanh USB-C 20W, Cáp Apple USB-C to USB-C 1m và Tai nghe Apple AirPods 2 vào Top-5. Các confidence tương ứng xấp xỉ 0,415358; 0,286213; 0,226876; 0,183246; 0,096859.

Chạy M3 nền flat với kulc-ir, beta=0,5 và lambda=0,75 cho thứ tự cuối: Ốp lưng silicon iPhone 15 (điểm 0,371460), Cáp Apple USB-C to USB-C 1m (0,184465), Kính cường lực iPhone 15 (0,307393), Tai nghe Apple AirPods 2 (0,090988), Củ sạc nhanh USB-C 20W (0,171247). Điểm không giảm đơn điệu trong danh sách cuối vì đã có bước đa dạng hóa dựa trên thứ hạng và danh mục. Toàn bộ năm mục vẫn có source association-rule.

Với Galaxy S24 FE không có ứng viên từ luật ở cấu hình này, M3 nền flat thay đổi thứ tự fallback và vẫn có thể chọn ốp iPhone vì không ghép M2. Chọn được nhiều danh mục hơn không bảo đảm tương thích. Các ví dụ lưu đầy đủ ID, luật nguồn, điểm và source trong tệp bằng chứng, giúp phân biệt tác động ranking với tác động của bộ lọc.

### 5.11.5. Ưu điểm, hạn chế và vị trí học thuật

M3 không cần khai phá lại cho từng chiến lược xếp hạng trên cùng mô hình nền và giữ được bằng chứng ứng viên. Đa dạng hóa có thể tránh danh sách quá lặp danh mục. Tuy nhiên, giới hạn nguồn ứng viên vẫn giữ nguyên: một sản phẩm bị miner hoặc M2 loại không được điểm M3 tự phục hồi. Xếp hạng có thể làm giảm catalog coverage dù độ đa dạng từng danh sách tăng.

Phương pháp tham lam là chuyển thể theo tinh thần marginal relevance và redundancy-aware top-k, không phải thuật toán nguyên bản của mục 7.5.2 áp dụng nguyên vẹn. Mức tương đồng chỉ là cùng category, không là một hàm khoảng cách semantic. Lựa chọn hai giai đoạn (tham số nền trước, xếp hạng sau) có thể bỏ lỡ tổ hợp tốt hơn nếu tối ưu chung.

## 5.12. Quy trình gợi ý tổng thể

Luồng đã tích hợp là orders→transactions→frequent itemsets→rules→single-item index→ranking/lọc→fallback→gắn giá→UI. M1 thay cách biểu diễn và khai phá/ánh xạ trong nghiên cứu; M2 thêm điều kiện mẫu và cặp ứng viên; M3 thay thứ tự/chọn Top-K. Các factory nghiên cứu có thể phối hợp nhưng không vì dùng lại service helper mà trở thành một phần API đang hoạt động.

![Hình 5.2. Quy trình thực nghiệm M1–M3 và ranh giới train/validation/test.](hinh_anh_so_do/research.png)

Bước chọn tham số chỉ học train và chấm validation. Sau chọn, mô hình được fit lại trên train∪validation rồi chấm test. Popularity và fallback phải được tính từ cùng lịch sử được phép; không lấy itemCounts toàn bộ orders của website khi chấm một phần test offline. Nếu dùng cache online không đúng thời điểm sẽ tạo rò rỉ dữ liệu ngay cả khi thuật toán mining không đổi.

## 5.13. Phân tích độ phức tạp

Gọi N là số giao dịch, m là số mục phân biệt, L là độ dài giao dịch lớn nhất, F là số tập phổ biến và R là số luật. Chuẩn hóa cần đọc tổng số mục và sắp từng giao dịch, có thể chặn trên bằng $O(NL\log L)$. ItemCounts có chi phí tuyến tính theo tổng độ dài sau chuẩn hóa. Đọc snapshot và giữ nó trong tiến trình cần bộ nhớ tỷ lệ với tổng số mục đã đọc.

Apriori có số ứng viên mức k tới $\binom{m}{k}$ trong trường hợp xấu; hiện thực đếm bằng lựa chọn giữa liệt kê tập con giao dịch và duyệt ứng viên. Một ước lượng phần đếm ở mức k là tổng theo giao dịch của giá trị nhỏ hơn giữa công việc liệt kê $\binom{|T|}{k}$ và kiểm tra $|C_k|$ ứng viên, có thêm chi phí dựng khóa/kiểm từng mục. Không đủ chính xác nếu chỉ ghi chung Apriori là O(N) hoặc O(m²).

FP-tree ban đầu có số nút không vượt tổng số mục phổ biến trong các giao dịch, nhưng tổng công việc dựng cây điều kiện phụ thuộc cấu trúc chia sẻ tiền tố. Trong trường hợp nhiều mẫu phổ biến, đầu ra tự nó đã có thể là $2^m-1$ tập. FP-Growth không có bảo đảm đa thức tổng quát chỉ vì không sinh candidate như Apriori.

Sinh luật từ các tập kích thước l cần $2^l-2$ cách chia mỗi tập, nên tổng công việc tỷ lệ với tổng các cách chia và chi phí tạo khóa/độ đo. M1 làm giao dịch dài thêm các tổ tiên và có thể tăng F; M2 giảm không gian theo ràng buộc nhưng thêm chi phí kiểm tra; M3 sắp m_c ứng viên $O(m_c\log m_c)$ và chọn tham lam Top-K khoảng $O(Km_c)$, cộng chi phí xử lý mảng. Đây là phân tích cấu trúc mã, không thay cho benchmark hoặc chặn trên tài nguyên production.

## 5.14. Ví dụ chạy xuyên suốt từ đơn hàng đến gợi ý

Ví dụ thực thi mới lấy dữ liệu giả lập R1b/20261101, kiểm tra checksum trùng manifest rồi tách thời gian. Chỉ 16.000 đơn lịch sử được dùng cho mining. Các ObjectId trong catalog là ID xác định từ bộ sinh, không lấy danh tính khách hàng. Với iPhone 15, support count singleton là 1.146; số đơn cùng Ốp lưng silicon iPhone 15 là 476, nên confidence bằng 476/1146≈0,415358.

MinSupport=0,002 tương ứng 32 đơn; cặp trên đạt ngưỡng. `generateRules` tạo luật có tiền đề iPhone 15 và hậu đề ốp; minConfidence=0 trong cấu hình minh họa không loại luật này. `indexSingleItemRules` đưa nó vào chỉ mục của iPhone 15. `rankRecommendations` kiểm lift>1 và sản phẩm còn hàng, chọn ốp ở vị trí đầu. Các mục có luật đủ năm nên không thêm fallback ở truy vấn này.

Nếu dùng ngưỡng mặc định website 0,01 và confidence 0,2 thì mô hình và danh sách có thể khác; ví dụ minh họa không được gọi là đầu ra mặc định production. Phần thực nghiệm so sánh cấu hình mặc định và cấu hình chọn validation bằng hai dòng riêng. Ví dụ mới chỉ giải thích cơ chế, không được cộng vào bộ 5 seed như một thực nghiệm mới có hiệu năng đo tương đương.

Đầu ra API có thể giữ product, rule, explanation và metadata cache. UI ở chế độ khách hiển thị thẻ sản phẩm theo nguồn, không đưa mọi chỉ số kỹ thuật vào hành trình mua hàng. Chế độ research có thể hiện confidence/support/lift để kiểm chứng. Kết luận có cơ sở là gợi ý có thể truy vết đến lịch sử và điều kiện lọc; chưa có cơ sở kết luận xác suất mua tương lai của một khách cụ thể bằng đúng confidence lịch sử.
