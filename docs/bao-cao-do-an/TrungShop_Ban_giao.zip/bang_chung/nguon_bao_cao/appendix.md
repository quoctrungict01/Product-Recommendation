
# PHỤ LỤC A. BẢN ĐỒ MÃ NGUỒN {.unnumbered}


Phạm vi kiểm kê gồm 260 tệp JS/JSX/CSS ngoài tài nguyên public. Manifest SHA-256 ghi rõ đường dẫn, số dòng và tên hàm nhận diện tĩnh; việc đếm tệp không tự chứng minh mọi nhánh đã chạy. Các đường trong bảng dưới tương đối với backend.

| Nhóm | Tệp | Trách nhiệm |
|---|---|---|
| Mining | src/apps/services/mining/transactions.js | Chuẩn hóa giao dịch và ngưỡng |
| Mining | src/apps/services/mining/apriori.js | Join/prune/count theo mức |
| Mining | src/apps/services/mining/fpgrowth.js | FP-tree và cây điều kiện |
| Mining | src/apps/services/mining/rules.js | Sinh luật và độ đo |
| Gợi ý | src/apps/services/recommendation/service.js | Cache và điều phối |
| Gợi ý | src/apps/services/recommendation/ranking.js | Luật 1→1, lọc và fallback |
| Gợi ý | src/apps/services/recommendation/loaders.js | Đọc order/product/fingerprint |
| M1 | research/multilevel/hierarchy.js | Cây phân cấp, mở rộng giao dịch |
| M1 | research/multilevel/mining.js | Ngưỡng cấp, lọc tầm thường, dư thừa |
| M1 | research/multilevel/recommender.js | Ánh xạ danh mục về sản phẩm |
| M2 | research/constraints/constraints.js | Phân loại ràng buộc |
| M2 | research/constraints/business.js | Heuristic nghiệp vụ |
| M2 | research/constraints/miners.js | Push/post |
| M2 | research/constraints/recommender.js | Ghép ràng buộc với gợi ý |
| M3 | research/ranking/strategies.js | Điểm và Top-K đa dạng |
| M3 | research/ranking/recommender.js | Factory phối hợp nền |
| Đánh giá | research/evaluation/split.js | Chia theo thời gian |
| Đánh giá | research/evaluation/protocol.js | Một sản phẩm xem, phần còn lại truth |
| Đánh giá | research/evaluation/metrics.js | Độ đo và bootstrap theo đơn |
| Dữ liệu | research/datasets/generator.js | R1/R1b, PRNG, checksum |

*Bảng A.1. Bản đồ module trọng tâm.*


# PHỤ LỤC B. DANH SÁCH ROUTE THEO ROUTER {.unnumbered}


Bảng được trích từ router hiện hành. Quyền của các nhóm có router.use được ghi riêng; không suy quyền từ regex trích route. Prefix mặc định `/api/v1`.

| Router | Phương thức | Đường con | Handler/middleware trong khai báo |
|---|---|---|---|
| auth.js | POST | `/login` | `loginLimit, asyncHandler(AuthController.login))` |
| auth.js | POST | `/register` | `registerLimit, asyncHandler(AuthController.register))` |
| auth.js | GET | `/me` | `requireAuth, asyncHandler(AuthController.me))` |
| auth.js | PUT | `/me` | `requireAuth, asyncHandler(AuthController.updateMe))` |
| auth.js | PUT | `/me/password` | `requireAuth, asyncHandler(AuthController.changePassword))` |
| category.js | POST | `/create` | `requireAdmin, asyncHandler(CategoryController.create))` |
| category.js | PUT | `/update/:id` | `requireAdmin, asyncHandler(CategoryController.update))` |
| category.js | DELETE | `/delete/:id` | `requireAdmin, asyncHandler(CategoryController.delete))` |
| category.js | GET | `/` | `asyncHandler(CategoryController.index))` |
| category.js | GET | `/:id` | `asyncHandler(CategoryController.show))` |
| category.js | GET | `/:id/products` | `asyncHandler(ProductController.getProductsByCategoryId))` |
| comment.js | GET | `/admin` | `asyncHandler(CommentController.list))` |
| comment.js | DELETE | `/admin/:id` | `asyncHandler(CommentController.remove))` |
| coupon.js | POST | `/preview` | `couponPreviewLimit, asyncHandler(OrderController.previewCoupon))` |
| coupon.js | GET | `/admin` | `requireAdmin, asyncHandler(CouponController.list))` |
| coupon.js | POST | `/admin` | `requireAdmin, asyncHandler(CouponController.create))` |
| coupon.js | GET | `/admin/:id` | `requireAdmin, asyncHandler(CouponController.show))` |
| coupon.js | PUT | `/admin/:id` | `requireAdmin, asyncHandler(CouponController.update))` |
| coupon.js | PATCH | `/admin/:id/status` | `requireAdmin, asyncHandler(CouponController.setStatus))` |
| order.js | POST | `/` | `optionalAuth, asyncHandler(OrderController.order))` |
| order.js | GET | `/my` | `requireAuth, asyncHandler(OrderController.myOrders))` |
| order.js | GET | `/getAll` | `requireAdmin, asyncHandler(OrderController.getAllOrders))` |
| order.js | GET | `/topProductPairs` | `requireAdmin, asyncHandler(OrderController.getTopProductPairsNames))` |
| order.js | GET | `/admin` | `requireAdmin, asyncHandler(OrderController.adminList))` |
| order.js | GET | `/admin/:id` | `requireAdmin, asyncHandler(OrderController.adminDetail))` |
| order.js | PATCH | `/admin/:id/status` | `requireAdmin, asyncHandler(OrderController.updateStatus))` |
| product.js | POST | `/create` | `requireAdmin, asyncHandler(ProductController.addProduct))` |
| product.js | POST | `/upload-image` | `requireAdmin, ProductController.uploadImage)` |
| product.js | GET | `/` | `asyncHandler(ProductController.index))` |
| product.js | GET | `/:id` | `asyncHandler(ProductController.show))` |
| product.js | GET | `/:id/comments` | `asyncHandler(ProductController.comments))` |
| product.js | POST | `/:id/comments` | `requireAuth, asyncHandler(ProductController.storeComments))` |
| product.js | DELETE | `/:id/comments/:commentId` | `requireAdmin, asyncHandler(ProductController.deleteComment))` |
| product.js | PUT | `/:id/update` | `requireAdmin, asyncHandler(ProductController.updateProduct))` |
| product.js | DELETE | `/:id/delete` | `requireAdmin, asyncHandler(ProductController.deleteProduct))` |
| product.js | GET | `/:id/product-suggestions` | `asyncHandler(ProductSuggestionsController.getProductSuggestions))` |
| recommendation.js | GET | `/products/:id` | `controller.forProduct)` |
| recommendation.js | GET | `/status` | `controller.status)` |
| recommendation.js | POST | `/refresh` | `controller.refresh)` |
| stats.js | GET | `/summary` | `asyncHandler(StatsController.summary))` |
| stats.js | GET | `/revenue` | `asyncHandler(StatsController.revenue))` |
| stats.js | GET | `/top-products` | `asyncHandler(StatsController.topProducts))` |
| user.js | POST | `/create` | `asyncHandler(UserController.create))` |
| user.js | PUT | `/update/:id` | `asyncHandler(UserController.update))` |
| user.js | DELETE | `/delete/:id` | `asyncHandler(UserController.delete))` |
| user.js | GET | `/` | `asyncHandler(UserController.index))` |
| user.js | GET | `/:id` | `asyncHandler(UserController.getById))` |

*Bảng B.1. Route khai báo trong các tệp router.*


Các router user, comment và stats áp requireAdmin toàn nhóm; các router còn lại có quyền theo từng route. Recommendation status công khai; refresh giới hạn peer loopback trong controller. Các đường con phải ghép với mount trong web.js.


# PHỤ LỤC C. NHẬT KÝ KIỂM CHỨNG {.unnumbered}


Ngày khảo sát: 02/11/2026 (UTC+7). Snapshot HEAD `a9c5a23280b695467aac045a36079c9dbf543163`. Các tệp nguồn không bị sửa để viết báo cáo; dependency được cài để chạy test.


Lệnh kiểm thử thành công: `/workspace/work/runtime/node_modules/node/bin/node --test test/*/*.test.js` tại backendapi, Node v20.20.2. Kết quả: 264 tests, 263 pass, 0 fail, 1 skipped. Test bị bỏ qua cần biến RECO_DB_IT=1 và MongoDB GR2 có dữ liệu; phiên khảo sát không chạy test DB thật. Log đầy đủ nằm trong bang_chung/test-node20.txt.


Lần kiểm thử Node v24.19.0 gặp lỗi Utils.isRegExp trong config. Đây là giới hạn tương thích runtime; log được giữ riêng, không thay kết quả Node 20. Các ví dụ thuần mining/M1/M2/M3 chạy được với Node 24 và được ghi trong examples.json. Chưa chạy bộ test React hoặc trình duyệt E2E.


Không chạy lại toàn bộ benchmark để tạo số thời gian mới. Các bảng Chương 6 lấy từ artifact cũ; ngày tạo, runtime và cách đo được giữ trong JSON/Markdown gốc. Script examples.js ghi minh họa từ R1b/20261101, không ghi MongoDB và không được dùng như benchmark.


# PHỤ LỤC D. CÁC BƯỚC TÁI LẬP {.unnumbered}


Cài dependency backend theo lockfile bằng npm ci; dùng Node 20 để tương thích dependency config hiện tại. Chạy test bằng mẫu glob tệp, không truyền tên thư mục cho Node 24 rồi giả định test runner tự tìm cùng cách. Không cần khóa JWT thật hoặc kết nối DB cho các test offline/fake-app đã có cấu hình thử nghiệm.


Các lệnh nghiên cứu: `node scripts/benchmark-research-datasets.js`; `node scripts/evaluate-research-datasets.js`; `node scripts/benchmark-multilevel.js`; `node scripts/evaluate-multilevel.js`; `node scripts/benchmark-constraints.js`; `node scripts/evaluate-constraints.js`; `node scripts/evaluate-ranking.js`. Mỗi script có thể ghi lại research-results; sao lưu artifact gốc trước khi tái lập để không lẫn kết quả hai môi trường.


Có thể chạy riêng `--profile r1b --seed 20261101`. Không chạy seed-demo ghi DB chỉ để tái lập thống kê offline. Đọc hướng dẫn và safety guard của script nếu cần tạo một DB demo riêng. Tệp examples.js có đường dẫn tuyệt đối của môi trường khảo sát; khi chuyển máy, sửa biến B về thư mục backend tương ứng.


# PHỤ LỤC E. DỮ LIỆU VÍ DỤ MỚI {.unnumbered}


Dataset R1b/20261101 có checksum `ac2ea12f86d60fe2c435b4a72ce9552d29e5cf99`, khớp manifest đã lưu. Lịch sử dùng 16000 đơn; số đếm singleton và đầu ra dưới đây được chạy trong phiên khảo sát. Các ví dụ là dữ liệu giả lập; không chứa thông tin cá nhân khách hàng.


## E.1. Samsung Galaxy S24 FE 128GB


ID: `ff2edeb364b264fd9bad99fb`; số đơn lịch sử chứa sản phẩm: 51.

| Mô hình | Vị trí | Sản phẩm | Nguồn | Điểm nếu có |
|---|---|---|---|---|
| flat | 1 | Samsung Galaxy S24 Ultra 256GB | fallback | — |
| flat | 2 | Samsung Galaxy A05s 128GB | fallback | — |
| flat | 3 | Samsung Galaxy S23 Ultra 256GB | fallback | — |
| flat | 4 | Samsung Galaxy M34 5G 128GB | fallback | — |
| flat | 5 | Samsung Galaxy S24+ 256GB | fallback | — |
| m1 | 1 | Củ sạc nhanh Samsung 45W | association-rule | 0.144024 |
| m1 | 2 | Ốp lưng Galaxy S24 Ultra | association-rule | 0.124966 |
| m1 | 3 | Kính cường lực Galaxy S24 Ultra | association-rule | 0.089573 |
| m1 | 4 | Tai nghe có dây Samsung IA500 | association-rule | 0.087122 |
| m1 | 5 | Ốp lưng trong suốt iPhone 14 series | association-rule | 0.024231 |
| m2 | 1 | Củ sạc nhanh USB-C 20W | fallback | — |
| m2 | 2 | Pin dự phòng Xiaomi 10.000mAh 20W | fallback | — |
| m2 | 3 | Tai nghe Apple AirPods 2 | fallback | — |
| m2 | 4 | Pin dự phòng Samsung 20.000mAh 45W | fallback | — |
| m2 | 5 | Cáp Apple USB-C to USB-C 1m | fallback | — |
| m3 | 1 | Samsung Galaxy S24 Ultra 256GB | fallback | — |
| m3 | 2 | Củ sạc nhanh USB-C 20W | fallback | — |
| m3 | 3 | Ốp lưng silicon iPhone 15 | fallback | — |
| m3 | 4 | Pin dự phòng Xiaomi 10.000mAh 20W | fallback | — |
| m3 | 5 | Tai nghe Apple AirPods 2 | fallback | — |

*Bảng E.1. Đầu ra minh họa Samsung Galaxy S24 FE 128GB.*


## E.2. iPhone 15 128GB


ID: `1d5ba7380b7670883116b85e`; số đơn lịch sử chứa sản phẩm: 1146.

| Mô hình | Vị trí | Sản phẩm | Nguồn | Điểm nếu có |
|---|---|---|---|---|
| flat | 1 | Ốp lưng silicon iPhone 15 | association-rule | — |
| flat | 2 | Kính cường lực iPhone 15 | association-rule | — |
| flat | 3 | Củ sạc nhanh USB-C 20W | association-rule | — |
| flat | 4 | Cáp Apple USB-C to USB-C 1m | association-rule | — |
| flat | 5 | Tai nghe Apple AirPods 2 | association-rule | — |
| m1 | 1 | Ốp lưng silicon iPhone 15 | association-rule | 0.415358 |
| m1 | 2 | Kính cường lực iPhone 15 | association-rule | 0.286213 |
| m1 | 3 | Củ sạc nhanh USB-C 20W | association-rule | 0.226876 |
| m1 | 4 | Cáp Apple USB-C to USB-C 1m | association-rule | 0.183246 |
| m1 | 5 | Tai nghe Apple AirPods 2 | association-rule | 0.096859 |
| m2 | 1 | Ốp lưng silicon iPhone 15 | association-rule | — |
| m2 | 2 | Kính cường lực iPhone 15 | association-rule | — |
| m2 | 3 | Củ sạc nhanh USB-C 20W | association-rule | — |
| m2 | 4 | Cáp Apple USB-C to USB-C 1m | association-rule | — |
| m2 | 5 | Tai nghe Apple AirPods 2 | association-rule | — |
| m3 | 1 | Ốp lưng silicon iPhone 15 | association-rule | 0.371460 |
| m3 | 2 | Cáp Apple USB-C to USB-C 1m | association-rule | 0.184465 |
| m3 | 3 | Kính cường lực iPhone 15 | association-rule | 0.307393 |
| m3 | 4 | Tai nghe Apple AirPods 2 | association-rule | 0.090988 |
| m3 | 5 | Củ sạc nhanh USB-C 20W | association-rule | 0.171247 |

*Bảng E.2. Đầu ra minh họa iPhone 15 128GB.*

