# CHƯƠNG 6. THỰC NGHIỆM VÀ ĐÁNH GIÁ

## 6.1. Môi trường thực nghiệm

Báo cáo phân biệt hai loại bằng chứng. Loại thứ nhất là các kết quả đã lưu trong `research-results`, được tạo ngày 26–27/10/2026, với metadata Node v20.20.2, win32 x64 và CPU Intel Core i7-1255U. Loại thứ hai là kiểm tra mới trong môi trường Linux của phiên khảo sát ngày 02/11/2026, gồm kiểm thử, tái sinh dữ liệu và ví dụ đầu ra. Không chuyển thời gian đo của máy cũ thành thành tích đo trên máy mới.

Benchmark R1/R1b khai phá train∪validation gồm 16.000 đơn. Mỗi lượt dùng một tiến trình con, có giới hạn heap 2.048 MB và thời gian 300 giây; số đo thời gian là trung vị 15 lần sau một lần chạy lạnh. RSS trong bảng là mức tăng bộ nhớ đỉnh lần chạy lạnh, dữ liệu được sinh ở tiến trình cha nên không bao gồm toàn bộ chi phí tạo dataset. Các giá trị là trung bình qua 5 seed của thống kê từng seed.

Benchmark mining giai đoạn đầu có cách đo khác: trung vị 7 lần, các bộ synthetic thay đổi độ dày, số đơn và ngưỡng. Không gộp các lần đo này với benchmark R1/R1b thành một bảng thời gian đồng nhất mà bỏ qua phương pháp. File JSON và Markdown được giữ trong gói bằng chứng để tra lại cấu hình và giá trị gốc.

## 6.2. Dữ liệu thực nghiệm

| Bộ dữ liệu | Quy mô | Đặc điểm | Phạm vi diễn giải |
|---|---|---|---|
| GR2-demo tái tạo offline | 1.000 đơn, 41 sản phẩm | Seed 20261026, luật mua kèm cài sẵn | Kiểm tra pipeline và baseline quy mô nhỏ |
| R1 | 5 seed × 20.000 đơn, 41 sản phẩm | Giống bộ sinh demo; 55% nhánh điện thoại, 35% phụ kiện, 10% nhiễu | Đo khả năng phục hồi cấu trúc giả lập |
| R1b | 5 seed × 20.000 đơn, 48 sản phẩm | Nhiễu 25%, 7 sản phẩm hiếm; tỷ lệ mua kèm giảm | Khảo sát thưa dữ liệu và độ bền |
| Synthetic mining | 1.000–50.000 giao dịch tùy cấu hình | Thay ngưỡng/độ dài/tập mục | Benchmark thuật toán, không phải đánh giá khách hàng |

*Bảng 6.1. Phân biệt dữ liệu demo, dữ liệu nghiên cứu và dữ liệu benchmark.*

Các seed nghiên cứu là 20261101, 20261102, 20261103, 20261104 và 20261105. Chúng là số nguyên điều khiển PRNG, không phải ngày xảy ra thực nghiệm; không suy luận có thử nghiệm trong tương lai từ hình thức chuỗi seed. Khoảng sinh đơn nghiên cứu được cấu hình từ 01/04/2026 đến 25/10/2026 theo UTC+7.

Manifest lưu `generatorVersion`, cấu hình, checksum dữ liệu và thống kê. Ví dụ R1 seed20261101 có checksum `e84322bb341aeb1d1ba300c07f06479f79de67dc`. GR2-demo có checksum đơn hàng `d1eb602b9280f67944583f56b7e9f832539a7925`. Checksum giúp phát hiện thay đổi nguồn, không phải bảo đảm dữ liệu mô phỏng đại diện cho thị trường thật.

Không tìm thấy bằng chứng về tập đơn mua thực của khách hàng đã được cung cấp để đánh giá. Dữ liệu demo được tái sinh trong bộ nhớ và không chứng minh MongoDB hiện đang chứa đúng 1.000 đơn. [CẦN BỔ SUNG: dữ liệu giao dịch thật đã ẩn danh, khoảng thời gian, quy tắc lọc trạng thái và quyền sử dụng.]

## 6.3. Cách sinh dữ liệu đơn hàng

`scripts/seed-demo/orders.js` chứa trọng số điện thoại PHONE_WEIGHTS, quan hệ COMPANIONS và gói ACCESSORY_BUNDLES. `research/datasets/generator.js` tái sử dụng các bảng và PRNG để tạo R1. R1b đổi tỷ lệ các nhánh: 43,8% điện thoại, 30% phụ kiện, 1,2% sản phẩm hiếm và 25% nhiễu. Xác suất mua kèm của nhánh thông thường được nhân 0,7; nhánh hiếm có các quan hệ riêng được khai báo.

Các tỷ lệ là xác suất chọn nhánh, không bảo đảm mỗi bộ 20.000 đơn có đúng tuyệt đối số lượng tương ứng. Các bảng quan hệ được lập trước khiến dữ liệu có mẫu để miner tìm lại. Chẳng hạn Galaxy S24 FE gắn với Ốp Galaxy S24 FE xác suất 0,7 và sạc Samsung 45W xác suất 0,4 trong nhánh hiếm. Một ràng buộc tên chọn đúng ốp có thể khớp với quy luật bộ sinh mà không cần khai phá được luật hiếm đó.

Sau sinh, các sản phẩm có ID xác định từ key, đơn có thời gian và items loại trùng. Dataset sắp theo thời gian và băm cả cấu hình, catalog, orders để có checksum. Các script đánh giá nghiên cứu không kết nối MongoDB. Việc chạy lại sinh dataset trong bộ nhớ là thao tác đọc/tính, khác với chạy `seed-demo.js` ghi vào DB; phiên khảo sát không seed hay sửa dữ liệu cửa hàng.

## 6.4. Thiết lập tham số và chống rò rỉ

`temporalSplit` dùng tỷ lệ 70/10/20, sắp time rồi id và dời ranh giới để không tách các đơn cùng timestamp. Vì có điều chỉnh ranh giới, không áp một con số chia cứng cho mọi dataset tùy ý nếu chưa kiểm tra. Với các bộ nghiên cứu đã lưu, lịch sử train∪validation là 16.000 đơn. Học tham số từ train, chấm validation, sau đó học lại train∪validation và chấm test.

`buildQueries` lấy mỗi sản phẩm trong một đơn có ít nhất hai sản phẩm khác nhau làm sản phẩm đang xem; các sản phẩm còn lại là truth. Giao thức giữ lại một mục làm ngữ cảnh, không phải truyền toàn bộ phần giỏ còn lại cho recommender. Một đơn sinh nhiều truy vấn có tương quan, nên bootstrap theo cụm đơn thay vì coi chúng hoàn toàn độc lập.

Các mặc định website là support 0,01, confidence 0,2, K=5. Baseline chọn validation dùng lưới ngưỡng khác và không được gọi là cùng cấu hình mặc định. M1 chọn ngưỡng danh mục/sản phẩm và policy; M2 chọn các ngưỡng nền; M3 chọn strategy, beta/gamma và lambda sau tham số nền. M3-R tối ưu recall validation; M3-C tối ưu coverage trong các cấu hình recall validation không thấp hơn mức tốt nhất quá 0,5 điểm phần trăm. Đây là tiêu chí đã khai báo trong code/báo cáo nghiên cứu, không chọn bằng kết quả test.

`assertMiningBudget` ước lượng số singleton phổ biến, số cặp, chiều dài giao dịch và cận trên tổng tập con. Các giới hạn mặc định là 5.000 mục phổ biến, 5.000.000 cặp, độ dài 24 và cận trên 20.000.000. Đây là hàng rào thận trọng trong nghiên cứu; luồng API mining mặc định không gọi trực tiếp bộ kiểm tra ngân sách này.

## 6.5. Kịch bản kiểm thử

| Nhóm | Kịch bản và kết quả mong đợi | Cơ sở kiểm tra |
|---|---|---|
| Chuẩn hóa | Mục trùng chỉ tính một đơn; rỗng giữ mẫu số | `test/mining/edge-cases.test.js` |
| Apriori | Bảng 6.1 của sách cho L1–L3 đúng | `test/mining/apriori.test.js` |
| FP-Growth | Header, cơ sở điều kiện, đầu ra đúng | `test/mining/fpgrowth.test.js` |
| Tương đương | Cùng data/ngưỡng cho cùng itemsets | `test/mining/equivalence.test.js` |
| Luật | Confidence/lift/Kulc/IR, thiếu subset phải báo lỗi | `test/mining/rules.test.js` |
| Gợi ý | Bỏ chính p, trùng, thiếu, hết hàng, lift≤1 | Các test recommendation |
| Cache | Dùng lại model, TTL/fingerprint/invalidate | `test/recommendation/service.test.js` |
| M1 | Mở rộng, ngưỡng riêng, tổ tiên, ánh xạ | Các test multilevel |
| M2 | Push=post, không ràng buộc=miner gốc | Các test constraints |
| M3 | Native=nền; nguồn luật/fallback đúng | `test/ranking/ranking.test.js` |
| Đánh giá | Không trùng tập, không fit dữ liệu tương lai | Các test evaluation |
| API nghiệp vụ | Quyền truy cập, giá DB, trạng thái, coupon | Các test security/admin/catalog/coupon |

*Bảng 6.2. Kịch bản được đối chiếu với bộ test hiện có.*

Bảng nêu phạm vi và kỳ vọng, không tự gắn “đạt” cho toàn bộ giao diện. Kết quả chạy mới được ghi trong phần nhật ký kiểm chứng và phụ lục. Một test dùng fake-app/model giả kiểm chứng hợp đồng/controller trong môi trường mô phỏng, không tự chứng minh query chạy trên MongoDB thật hoặc CSS hiển thị đúng trên mọi trình duyệt.

## 6.6. Kiểm thử chức năng website

Repository có các test frontend cho Cart, CheckoutForm, Account, PriceTag, ProductBrowser, Header và FrequentlyBoughtTogether; phía Admin có test Product, Category, Order, Coupon, User, Comment và Dashboard. Sự hiện diện của test chỉ chứng minh có kịch bản được viết. Phiên khảo sát ưu tiên chạy lại backend/thuật toán và chưa có bằng chứng chạy toàn bộ test React hoặc kịch bản end-to-end trên trình duyệt.

Bộ fake-app phía backend cho phép kiểm tra phân quyền, không lộ password, bảo vệ đơn cá nhân, dùng giá DB, từ chối hàng hết, giới hạn coupon và đổi trạng thái. Những test này hữu ích vì phát hiện sai nghiệp vụ mà không cần dữ liệu thật. Tuy nhiên thiếu bằng chứng trực quan của bản chạy, cấu hình CORS production, phiên làm việc thực và tích hợp địa chỉ ngoài hệ thống.

Test MongoDB GR2 có điều kiện `RECO_DB_IT=1`, mặc định skip; nó chỉ đọc và kiểm tra số bản ghi trước/sau. Báo cáo không đổi skip thành pass hoặc kích hoạt kết nối đến DB chưa có cấu hình. [CẦN BỔ SUNG: chạy kiểm thử MongoDB thật với dữ liệu phù hợp và lưu log, chạy test Shop/Admin, chụp ảnh giao diện và kiểm thử đặt hàng qua trình duyệt.]

## 6.7. Kiểm thử thuật toán khai phá

Các fixture tái hiện ví dụ sách giúp kiểm tra support và cấu trúc cây có kết quả biết trước. Test tương đương giữa Apriori và FP-Growth tăng khả năng phát hiện lỗi hiện thực, nhưng hai thuật toán cùng một lỗi chuẩn hóa vẫn có thể cho cùng kết quả sai. Vì vậy cần cả fixture tay, công thức độ đo và kiểm tra các trường hợp ngoại lệ.

Các test edge bao gồm dữ liệu rỗng, mục trùng, ngưỡng không hợp lệ và trường hợp không có tập phổ biến. Test M1 kiểm hệ phân cấp và không xuất luật tổ tiên; test M2 so push/post và tính chất ràng buộc; test M3 so native và nguồn fallback. Tính đúng trên những bộ này là bằng chứng cài đặt, không thay cho đánh giá mức hữu ích với khách hàng.

Trong lần khảo sát, tái sinh R1b seed20261101 và chạy ví dụ p→q đã thực hiện thành công với Node v24.19.0. Tuy nhiên chạy toàn bộ backend trên Node 24 gặp lỗi tương thích `Utils.isRegExp is not a function` trong dependency `config`. Lỗi môi trường này được giữ trong log ban đầu và không trình bày như lỗi công thức Apriori/FP-Growth. Kết quả kiểm thử bằng runtime phù hợp được ghi riêng trong nhật ký kiểm chứng đi kèm.

## 6.8. So sánh Apriori và FP-Growth

Bảng 6.3 lấy đúng các dòng trong `phase4-step2-benchmark.md` và đối chiếu artifact JSON. Đơn vị thời gian là ms, TB±SD qua năm seed của trung vị mỗi seed; khai phá 16.000 đơn lịch sử, không gồm API/cache.

| Hồ sơ | Support | Apriori (ms) | FP-Growth (ms) | A/FP | Kết quả |
|---|---|---|---|---|---|
| R1 | 0,01 | 15,3 ± 0,5 | 18,7 ± 0,3 | 0,82 | Trùng 5/5 |
| R1 | 0,005 | 15,6 ± 0,2 | 18,7 ± 0,3 | 0,84 | Trùng 5/5 |
| R1 | 0,002 | 16,5 ± 0,5 | 18,8 ± 0,6 | 0,88 | Trùng 5/5 |
| R1b | 0,01 | 18,2 ± 3,9 | 25,5 ± 3,8 | 0,71 | Trùng 5/5 |
| R1b | 0,005 | 17,8 ± 3,4 | 26,0 ± 6,3 | 0,70 | Trùng 5/5 |
| R1b | 0,002 | 20,3 ± 2,2 | 26,8 ± 1,9 | 0,76 | Trùng 5/5 |

*Bảng 6.3. Benchmark một cấp trên R1/R1b đã lưu trong repository.*

![Hình 6.1. Thời gian một cấp R1/R1b theo Bảng 6.3; biểu đồ tái vẽ từ số liệu đã lưu.](hinh_anh_so_do/benchmark.png)

Apriori nhanh hơn trong những cấu hình thưa này. Dữ liệu ít mục mỗi đơn làm số ứng viên cần đếm tương đối nhỏ, trong khi dựng cây và cơ sở điều kiện có overhead. Không diễn giải mặc định FP-Growth của website như một kết luận rằng thuật toán đó luôn nhanh nhất. Độ đúng tập phổ biến giống nhau không kéo theo thời gian hoặc bộ nhớ giống nhau.

Bộ synthetic dày trong `benchmark-mining.md` có N=5.000, 100 item, độ dài giỏ trung bình 10. Tại support 2%, Apriori 196,3 ms, FP-Growth 60,7 ms, tỷ lệ khoảng 3,2. Đây là bộ khác R1/R1b, cho thấy lợi thế FP-Growth khi cấu trúc dày hơn và có khả năng nén. So sánh này hỗ trợ giải thích phụ thuộc dữ liệu, không phải phép nội suy độ trễ cho website thật.

## 6.9. Đánh giá M1

Bảng 6.4 sử dụng các dòng tương ứng từ báo cáo M3 tổng hợp, vì cùng một giao thức cung cấp baseline đã chọn ngưỡng và các mô hình nền. Tất cả số là phần trăm TB±SD qua năm seed test. “Website” là cấu hình mặc định, “một cấp” là cấu hình chọn bằng validation.

| Hồ sơ/phương pháp | P@5 | R@5 | Hit@5 | Coverage |
|---|---|---|---|---|
| R1 – Website | 22,6 ± 0,4 | 64,3 ± 0,8 | 70,3 ± 0,9 | 97,6 ± 0,0 |
| R1 – Một cấp | 28,5 ± 0,4 | 81,8 ± 0,3 | 84,1 ± 0,4 | 89,8 ± 1,1 |
| R1 – M1 | 28,5 ± 0,4 | 82,0 ± 0,5 | 84,3 ± 0,5 | 83,4 ± 1,1 |
| R1b – Website | 11,7 ± 0,3 | 36,8 ± 0,9 | 47,4 ± 0,7 | 89,6 ± 0,0 |
| R1b – Một cấp | 17,2 ± 0,4 | 55,9 ± 1,0 | 63,1 ± 1,0 | 86,3 ± 2,4 |
| R1b – M1 | 17,4 ± 0,3 | 56,3 ± 0,9 | 63,8 ± 0,8 | 81,3 ± 4,2 |

*Bảng 6.4. So sánh M1 với mặc định và baseline đã chọn ngưỡng.*

Lợi ích toàn bộ truy vấn của M1 so baseline đã chọn ngưỡng là nhỏ: khoảng 0,2 điểm recall ở R1 và 0,4 điểm ở R1b theo số đã làm tròn. Không gán chênh lệch từ 36,8 lên 56,3 hoàn toàn cho M1, vì baseline một cấp đã đạt 55,9 nhờ thay cách chọn tham số. Coverage giảm khi thứ tự cụ thể và luật danh mục tập trung vào những sản phẩm có bằng chứng chung.

Trong nhóm truy vấn mà sản phẩm xem là hiếm của R1b, recall baseline một cấp là 16,7±18,0%, M1 là 37,7±18,3%. Kết quả hỗ trợ giả thuyết hierarchy có ích khi sản phẩm ít đơn, nhưng nhóm chỉ có khoảng 62 truy vấn/seed, SD lớn. Phải phân biệt “recall khi tiền đề hiếm” với “tỷ lệ sản phẩm hiếm từng được gợi ý ở hậu đề”: chỉ số thứ hai của M1 có thể thấp hơn baseline.

Chi phí tăng rõ: ở R1 support 0,002, độ dài giao dịch trung bình 1,82→3,43; itemset 169→1.770; Apriori 20,8→134,6 ms và FP-Growth 24,8→41,0 ms trong cặp đo M1. Số liệu lấy từ benchmark M1, không ghép 20,8 với 18,8 ở một lượt benchmark khác. Hiệu ứng mở rộng taxonomy làm tăng không gian mẫu và giải thích chi phí bổ sung.

## 6.10. Đánh giá M2

| Hồ sơ/phương pháp | R@5 (%) | Coverage (%) | Hợp lý nghiệp vụ (%) |
|---|---|---|---|
| R1 – Một cấp | 81,8 ± 0,3 | 89,8 ± 1,1 | 83,0 ± 1,0 |
| R1 – M2 | 81,7 ± 0,2 | 73,2 ± 1,7 | 100,0 ± 0,0 |
| R1 – M1+M2 | 81,9 ± 0,4 | 73,2 ± 1,7 | 100,0 ± 0,0 |
| R1b – Một cấp | 55,9 ± 1,0 | 86,3 ± 2,4 | 72,6 ± 1,0 |
| R1b – M2 | 56,6 ± 0,7 | 69,2 ± 3,4 | 100,0 ± 0,0 |
| R1b – M1+M2 | 56,9 ± 0,9 | 69,2 ± 3,4 | 100,0 ± 0,0 |

*Bảng 6.5. M2 cải thiện tuân thủ ràng buộc nhưng giảm độ phủ catalog.*

100% tuân thủ là hệ quả của dùng cùng các điều kiện A2–A4 để lọc và chấm. Số liệu không chứng minh tương thích kỹ thuật hoàn toàn. Recall không suy giảm đáng kể ở các bộ giả lập này, nhưng không có bảo đảm cùng kết quả trên catalog khác, nơi tên sản phẩm thiếu chuẩn hoặc nhiều quan hệ hợp lệ bị quy tắc loại.

M2-B push/post cho cùng tập mục ở các cấu hình benchmark đã lưu; lợi ích tính toán phụ thuộc thuật toán. Trên R1b đa mức support 0,002, Apriori hậu lọc 103,9 ms và cắt tỉa 34,2 ms; candidate thực đếm giảm 3.790→639. FP-Growth cùng cấu hình hậu lọc 41,4 ms và push 53,4 ms: có cắt bớt cây nhưng overhead kiểm tra làm chậm hơn. Tỷ lệ “nhanh hơn” dưới 1 phải đọc là chậm hơn, không làm tròn thành một cải thiện.

## 6.11. Đánh giá M3

| Hồ sơ/phương pháp | R@5 (%) | Hit@5 (%) | Coverage (%) | Đa dạng danh mục (%) |
|---|---|---|---|---|
| R1 – Một cấp | 81,8 ± 0,3 | 84,1 ± 0,4 | 89,8 ± 1,1 | 66,7 ± 1,0 |
| R1 – M3-R | 82,3 ± 0,4 | 86,3 ± 0,8 | 86,3 ± 4,4 | 70,3 ± 6,5 |
| R1 – M3-C | 82,3 ± 0,3 | 85,9 ± 1,3 | 90,2 ± 0,0 | 65,2 ± 1,6 |
| R1b – Một cấp | 55,9 ± 1,0 | 63,1 ± 1,0 | 86,3 ± 2,4 | 62,2 ± 0,7 |
| R1b – M3-R | 56,2 ± 0,7 | 63,7 ± 0,3 | 72,5 ± 4,0 | 77,8 ± 7,1 |
| R1b – M3-C | 56,2 ± 0,7 | 63,7 ± 0,6 | 77,5 ± 9,0 | 72,1 ± 10,9 |

*Bảng 6.6. Tác động xếp hạng và tiêu chí chọn tham số M3.*

M3 có lợi ích nhỏ về recall, rõ hơn ở hit và đa dạng một số cấu hình. Trên R1b, M3-R tăng đa dạng nhưng giảm coverage hơn 13 điểm so baseline. Đa dạng đo số danh mục khác nhau chia độ dài từng danh sách; coverage đo số sản phẩm khác nhau được gợi ý trên toàn tập. Một danh sách đa dạng theo category vẫn có thể tập trung vào vài sản phẩm bán chạy lặp lại ở nhiều truy vấn.

Trên M1 hoặc M1+M2, validation thường chọn native và lambda=1; kết quả M3 gần như không đổi. Không nên mô tả mọi tổ hợp M1+M2+M3 là tốt hơn từng mô hình độc lập. Các phương pháp đều cần một tiêu chí chọn phù hợp và có thể tốt ở một mặt nhưng kém ở mặt khác.

Một kết quả cần đặc biệt thận trọng là recall nhóm hiếm 81,4±5,8% của M2+M3-C trên R1b. Báo cáo nghiên cứu phân tích toàn bộ mục cho máy hiếm trong tình huống này là fallback, không có luật. Tri thức tương thích theo tên lọc ra ốp đúng dòng, còn bộ sinh đã cài chính ốp đó làm companion. Vì vậy đây chủ yếu là lợi ích của tri thức và cấu trúc mô phỏng, không là bằng chứng miner khám phá quan hệ hiếm với recall 81,4%.

![Hình 6.2. Recall và coverage trên R1b; số liệu đã lưu, không phải đo mới.](hinh_anh_so_do/tradeoff.png)

## 6.12. Thời gian chạy và tài nguyên

Thời gian cần phân biệt load dữ liệu, mining, sinh luật, xếp hạng, truy vấn bổ sung giá, truyền mạng và render. Trường meta.miningMs của service đo lần khai phá mô hình; ở cache hit nó vẫn là thời gian lần model được tạo, không phải thời gian request hiện tại. Dùng giá trị đó làm biểu đồ độ trễ API có cache sẽ gây hiểu nhầm.

RSS là bộ nhớ thường trú của tiến trình, không đồng nghĩa heap JavaScript hoặc toàn bộ bộ nhớ ứng dụng. Giá trị tăng RSS nhỏ/không dương có thể chịu ảnh hưởng GC và cấp phát hệ điều hành; không diễn giải dấu gạch trong bảng cũ thành 0 MB. Benchmark chưa bao gồm tải đồng thời, MongoDB, hai frontend và nhiều model cache online nên không thể suy từ RSS mining dưới khoảng vài chục MB thành cấu hình RAM production tối thiểu.

Nhánh nghiên cứu dùng tiến trình con và budget để giới hạn; API mặc định chưa dùng worker và budget đó. Hướng cải tiến thực tế là khai phá định kỳ nền, chỉ giữ luật 1→1 cần thiết, giới hạn model cache và phân phối phiên bản mô hình. Cần đo lại sau mỗi thay đổi, vì loại việc sinh luật không dùng có thể quan trọng hơn đổi thuật toán khi danh mục nhỏ.

## 6.13. Phân tích kết quả

Chọn ngưỡng trên validation là cải thiện lớn nhất trong dữ liệu đã lưu: recall R1 từ 64,3 lên 81,8%, R1b từ 36,8 lên 55,9% ở baseline một cấp. Đây là khác biệt về cấu hình và quy trình chọn tham số. M1 cải thiện nhóm hiếm nhờ khái quát hóa; M2 kiểm soát hướng gợi ý và heuristic tương thích; M3 cân bằng thứ tự và danh mục. Mỗi nhận định cần gắn đúng biến đổi đã thực hiện.

Các chỉ số hiện thực được xác định rõ như sau, với Q là tập truy vấn, G_q là truth, R_q là Top-K:

$$P@K=\frac{1}{|Q|}\sum_q\frac{|R_q\cap G_q|}{K},\quad R@K=\frac{1}{|Q|}\sum_q\frac{|R_q\cap G_q|}{|G_q|}. \tag{6.1}$$

$$Hit@K=\frac{1}{|Q|}\sum_q\mathbf1[|R_q\cap G_q|>0],\quad Coverage=\frac{|\bigcup_qR_q|}{|I|}. \tag{6.2}$$

Danh sách thiếu K vẫn chia K trong precision, nên mô hình rules-only bị phản ánh phần chỗ trống. Truth chỉ lấy từ đơn nhiều sản phẩm, làm giao thức tập trung vào đồng mua và bỏ đơn đơn lẻ. Việc lấy trung bình theo truy vấn khiến đơn có nhiều mục đóng góp nhiều truy vấn hơn; bootstrap theo đơn xử lý phụ thuộc nhưng không đổi trọng số định nghĩa chỉ số.

SD qua seed đo biến thiên của các lần sinh cùng cơ chế; khoảng tin cậy bootstrap theo đơn là một đối tượng thống kê khác. Không gọi một cột TB±SD là khoảng tin cậy 95%. Các bảng báo cáo gốc có so sánh cặp trên cùng truy vấn, phù hợp hơn so hai khoảng tin cậy độc lập bằng mắt. Các số làm tròn 0,1 điểm không đủ tự xác định ý nghĩa thống kê.

## 6.14. Hạn chế của thực nghiệm

Dữ liệu mô phỏng có quy luật cài sẵn và ít biến động theo thời gian; không có hiệu ứng giá, quảng cáo, thiếu hàng hoặc nhóm khách thay đổi như môi trường thật. Năm seed không đại diện năm cửa hàng độc lập. Nhóm hiếm nhỏ và tri thức tương thích phần nào trùng với cách sinh companion nên một số kết quả có thể lạc quan.

Hierarchy chỉ có hai cấp dữ liệu; thuật toán tổng quát hỗ trợ nhiều cấp nhưng chưa có bằng chứng hiệu quả trên taxonomy sâu. M2 suy từ tên, không từ thông số cổng, kích thước hay giao thức. M3 chỉ phạt category, chưa có tương đồng semantic và chưa tối ưu chung mọi tham số nền/ranking. Các chỉ số set-based không nhạy với thứ tự khi Top-5 giữ nguyên; chưa dùng NDCG/MRR trong đánh giá hiện tại.

Benchmark được đo trên một máy và lưu từ trước; phiên khảo sát không chạy lại toàn bộ 10 bộ benchmark để tự tạo một bộ số mới. Chưa có thử nghiệm tải, A/B test, tỷ lệ nhấp hoặc đơn phát sinh do gợi ý. Chưa có ảnh UI thực tế và kiểm chứng MongoDB đang triển khai. Những thiếu hụt này được đánh dấu để bổ sung, không dùng số liệu ước lượng thay thế.

# CHƯƠNG 7. KẾT LUẬN VÀ HƯỚNG PHÁT TRIỂN

## 7.1. Kết quả đạt được

Đối chiếu mã nguồn xác định TrungShop có các khối website cần thiết cho duyệt hàng, tài khoản, giỏ, tiếp nhận và quản lý đơn, coupon, bình luận và thống kê. Luồng gợi ý một cấp đã được nối từ component trang chi tiết qua API đến module mining. Hai thuật toán có hợp đồng chung, nhiều fixture đối chiếu sách và cơ chế nguồn gợi ý rõ ràng.

Nhánh nghiên cứu cài đặt M1, M2, M3 và bộ đánh giá theo thời gian. Kết quả lưu cho phép quan sát lợi ích của hierarchy đối với mục ít dữ liệu, ràng buộc đối với mức tuân thủ và ranking đối với đa dạng. Lần khảo sát còn tái hiện các ví dụ đầu ra từ một dataset có checksum xác định. Các kết quả này không làm thay đổi kết luận rằng M1–M3 chưa được gọi trong website mặc định.

## 7.2. Những đóng góp của đồ án

Đóng góp kỹ thuật là tách mining khỏi DB, dùng cùng chuẩn hóa/ngưỡng cho Apriori và FP-Growth, giữ chỉ mục luật để chọn theo sản phẩm, phối hợp cache snapshot và cache mô hình, phân biệt fallback trên API và UI. Đóng góp về hệ thống là không tin giá từ trình duyệt, bảo vệ đơn của tài khoản và giữ lịch sử giá/trạng thái.

Đóng góp nghiên cứu là áp dụng có kiểm soát các ý tưởng trong Chương 6–7 của giáo trình vào cấu trúc catalog hiện có, xây ràng buộc có tính chất toán học rõ, và khảo sát công thức ranking do đồ án lựa chọn. Giá trị của nghiên cứu nằm cả ở các kết quả không cải thiện: push có thể chậm FP-Growth, đa dạng có thể giảm coverage và M3 có thể không thêm lợi ích trên M1.

## 7.3. Những hạn chế

Các giới hạn chính là thiếu dữ liệu giao dịch thật và đánh giá kinh doanh, chưa tích hợp các mô hình nâng cao, chưa kiểm chứng UI/DB trong môi trường triển khai, chưa có kho định lượng hoặc cổng thanh toán. Cache trong tiến trình có khả năng cũ khi sửa đơn và không chia sẻ giữa nhiều instance; mining đồng bộ có rủi ro ảnh hưởng API khi dữ liệu hoặc số cấu hình tăng.

Ở mức mô hình, luật đồng mua không tự chứng minh tương thích hoặc cá nhân hóa. Taxonomy phẳng giới hạn chiều sâu M1; tri thức tên giới hạn M2; heuristic danh mục giới hạn M3. Các ưu điểm chỉ có ý nghĩa trong điều kiện dữ liệu và mục tiêu đánh giá đã khai báo, không nên mở rộng thành khẳng định hoàn thiện cho mọi cửa hàng.

## 7.4. Hướng phát triển

Ưu tiên đầu là chuẩn hóa tiêu chuẩn dữ liệu học: chọn trạng thái đơn được phép, xử lý đơn trùng/hủy, xác định khoảng thời gian và kiểm tra biến động. Thu thập dữ liệu thật có quyền sử dụng, chia thời gian và chọn lại tham số với baseline phù hợp. Chỉ sau đó mới quyết định mức mở rộng cần thiết; ngưỡng tốt nhất trên mô phỏng không tự động là ngưỡng triển khai.

Ưu tiên tiếp là chuyển mining sang tác vụ nền hoặc worker, giới hạn số mô hình cache, bổ sung version dữ liệu và kiểm tra race khi refresh. Cần chuẩn hóa price số và cải tiến query giá để tránh đọc toàn bộ ứng viên trong RAM. Các quy tắc tiền/đơn phải giữ tương thích lịch sử khi di trú schema.

Về nghiên cứu, nên xây ontology tương thích dựa trên thuộc tính cấu trúc, đánh giá độc lập bởi người có chuyên môn, rồi cân nhắc M2 cho cả luật và fallback. Chỉ dùng M1 khi dữ liệu thật đủ minh chứng nhu cầu khái quát hóa; M3 cần thêm chỉ số theo thứ hạng, kiểm tra tác động lên coverage và điều chỉnh lambda. Khi có hạ tầng, đánh giá A/B bằng tỷ lệ nhấp, thêm giỏ và mua, đồng thời giữ nhãn nguồn để phân tích đóng góp của luật so với fallback.

# TÀI LIỆU THAM KHẢO {.unnumbered}

[1] Jiawei Han, Micheline Kamber, Jian Pei. *Data Mining: Concepts and Techniques*. Third Edition. Morgan Kaufmann/Elsevier, 2012. ISBN 978-0-12-381479-1. Bản PDF được cung cấp trong repository; năm 2012 theo trang bản quyền của bản này. Đối chiếu Chương 6: §6.2.1 Apriori, §6.2.2 sinh luật, §6.2.4 FP-Growth, §6.3.2–6.3.3 độ đo; Chương 7: §7.2.1 đa mức, §7.3.1 metarule, §7.3.2 ràng buộc, §7.5.2 top-k giảm dư thừa. Không gán số trang chưa đối chiếu cho trích dẫn.

[2] Rakesh Agrawal, Ramakrishnan Srikant. “Fast Algorithms for Mining Association Rules.” *Proceedings of the 20th International Conference on Very Large Data Bases (VLDB)*, 1994. Tài liệu gốc của Apriori; báo cáo dùng [1] để đối chiếu chi tiết thuật toán và ví dụ.

[3] Jiawei Han, Jian Pei, Yiwen Yin. “Mining Frequent Patterns without Candidate Generation.” *Proceedings of the ACM SIGMOD International Conference on Management of Data*, 2000. DOI: 10.1145/342009.335372. Công trình nền về FP-Growth.

[4] Ramakrishnan Srikant, Rakesh Agrawal. “Mining Generalized Association Rules.” *Proceedings of the 21st International Conference on Very Large Data Bases (VLDB)*, 1995. Nền tảng khai phá quan hệ tổng quát qua hierarchy.

[5] React. *React Documentation*. https://react.dev/ — nguồn chính thức; phiên bản dependency của đồ án căn cứ package.json và lockfile, không suy từ phiên bản tài liệu hiện hành.

[6] Express. *Express 4.x API Reference*. https://expressjs.com/en/4x/api.html — router, middleware, request và response.

[7] MongoDB. *MongoDB Manual: Data Modeling*. https://www.mongodb.com/docs/manual/data-modeling/ — tài liệu nhúng và tham chiếu.

[8] Mongoose. *Mongoose 6 Documentation*. https://mongoosejs.com/docs/6.x/ — schema, model và truy vấn.

[9] Node.js. *Node.js Documentation*. https://nodejs.org/docs/latest-v20.x/api/ — runtime và test runner. Phiên bản thực nghiệm được ghi riêng theo log.

[10] M. Jones, J. Bradley, N. Sakimura. *JSON Web Token (JWT)*. RFC 7519, IETF, 2015. https://www.rfc-editor.org/rfc/rfc7519 — định dạng token; quy tắc role và thu hồi trong TrungShop là quyết định ứng dụng.

[11] Repository *Product-Recommendation*. Snapshot khảo sát HEAD `a9c5a23280b695467aac045a36079c9dbf543163`. Các phần `Shop/Shop/backendapi/src`, `research`, `scripts`, `test`, `research-results`, `Shop/Shop/frontend/src` và `Admin/Admin/src`. Mã nguồn là bằng chứng hiện thực, không thay thế tài liệu lý thuyết.

Các đường dẫn tài liệu công nghệ trên là nguồn chính thức để tra cứu; nội dung phiên khảo sát được đối chiếu trực tiếp với mã và bản sách cục bộ, chưa kiểm tra trực tuyến toàn văn từng trang tài liệu công nghệ. Khi hoàn thiện theo mẫu trường, sinh viên cần thống nhất chuẩn trích dẫn và bổ sung ngày truy cập thực tế nếu yêu cầu.
