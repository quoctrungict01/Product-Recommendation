from docx import Document
from docx.shared import Cm,Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT
from pathlib import Path
p=Path('/workspace/output/Bao_cao_do_an_tot_nghiep_TrungShop.docx');d=Document(p)
styles={st.name:st for st in d.styles}
sec=d.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=Cm(3);sec.right_margin=Cm(2);sec.top_margin=Cm(2);sec.bottom_margin=Cm(2);sec.header_distance=Cm(.8);sec.footer_distance=Cm(.8);sec.different_first_page_header_footer=True
num=OxmlElement('w:pgNumType');num.set(qn('w:start'),'0');sec._sectPr.append(num)
for name in ['Normal','Body Text','First Paragraph']:
 st=styles[name];st.font.name='Times New Roman';st.font.size=Pt(13)
 st.paragraph_format.line_spacing=1.5;st.paragraph_format.space_after=Pt(6);st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY;st.paragraph_format.widow_control=True
for lev,size in [(1,16),(2,14),(3,13),(4,13)]:
 st=styles['Heading '+str(lev)];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.bold=True;st.font.color.rgb=None
 st.paragraph_format.keep_with_next=True;st.paragraph_format.keep_together=True;st.paragraph_format.space_before=Pt(12);st.paragraph_format.space_after=Pt(8);st.paragraph_format.line_spacing=1.2
 if lev==1:st.paragraph_format.page_break_before=True
for name in ['Caption','Image Caption','Table Caption']:
 if name in d.styles:
  st=styles[name];st.font.name='Times New Roman';st.font.size=Pt(11);st.font.italic=True;st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER;st.paragraph_format.line_spacing=1.1;st.paragraph_format.keep_together=True
for name in ['Verbatim Char','Source Code']:
 if name in d.styles:styles[name].font.size=Pt(9)
for st in d.styles:
 if st.type==1 or st.type==2:
  rpr=st.element.get_or_add_rPr();fonts=rpr.find(qn('w:rFonts'))
  if fonts is None:fonts=OxmlElement('w:rFonts');rpr.insert(0,fonts)
  for k in ['ascii','hAnsi','eastAsia','cs']:fonts.set(qn('w:'+k),'Times New Roman')
for para in d.paragraphs:
 if para.style.name in ['Normal','Body Text','First Paragraph']:
  para.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
 if para._p.xpath('.//w:drawing'):para.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
for t in d.tables:
 t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 cols=len(t.columns);w=16/cols
 for col in t.columns:col.width=Cm(w)
 for ri,row in enumerate(t.rows):
  trpr=row._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
  if ri==0:
   rep=OxmlElement('w:tblHeader');trpr.append(rep)
  for cell in row.cells:
   cell.width=Cm(w)
   for para in cell.paragraphs:
    para.paragraph_format.line_spacing=1.05;para.paragraph_format.space_after=Pt(4);para.paragraph_format.space_before=Pt(3);para.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
    for r in para.runs:r.font.name='Times New Roman';r.font.size=Pt(10 if cols>=5 else 11);r.font.bold=ri==0
# Word updateable fields, with cached instructions instead of invented page numbers.
def field(para,code,cached):
 run=para.add_run();begin=OxmlElement('w:fldChar');begin.set(qn('w:fldCharType'),'begin');run._r.append(begin)
 run=para.add_run();instr=OxmlElement('w:instrText');instr.set(qn('xml:space'),'preserve');instr.text=code;run._r.append(instr)
 run=para.add_run();sep=OxmlElement('w:fldChar');sep.set(qn('w:fldCharType'),'separate');run._r.append(sep)
 para.add_run(cached)
 run=para.add_run();end=OxmlElement('w:fldChar');end.set(qn('w:fldCharType'),'end');run._r.append(end)
def after(para):
 el=OxmlElement('w:p');para._p.addnext(el)
 from docx.text.paragraph import Paragraph
 return Paragraph(el,para._parent)
for para in list(d.paragraphs):
 if para.text.strip()=='MỤC LỤC':field(after(para),' TOC \\o "1-3" \\h \\z \\u ','Mục lục tự động: mở bằng Microsoft Word, chọn toàn bộ và cập nhật trường (F9) để hiển thị số trang theo bố cục Word.')
 if para.text.strip()=='DANH MỤC HÌNH':field(after(para),' TOC \\h \\z \\t "Image Caption,1" ','Danh mục hình tự động lấy theo chú thích hình; cập nhật trường trong Word.')
 if para.text.strip()=='DANH MỤC BẢNG':field(after(para),' TOC \\h \\z \\t "Table Caption,1" ','Danh mục bảng tự động lấy theo chú thích bảng; cập nhật trường trong Word.')
# Cover before all report paragraphs
first=d.paragraphs[0]
cover=[('[CẦN BỔ SUNG: TÊN TRƯỜNG]',13,True),('[CẦN BỔ SUNG: KHOA / VIỆN]',13,True),('',13,False),('BÁO CÁO ĐỒ ÁN TỐT NGHIỆP',18,True),('',13,False),('XÂY DỰNG WEBSITE THƯƠNG MẠI ĐIỆN TỬ TRUNGSHOP KẾT HỢP HỆ THỐNG GỢI Ý SẢN PHẨM DỰA TRÊN KHAI PHÁ LUẬT KẾT HỢP',16,True),('',13,False),('Sinh viên thực hiện: Trần Quốc Trung',13,False),('Mã số sinh viên: 20200648',13,False),('Lớp: ICT-01 K65',13,False),('Giảng viên hướng dẫn: Trần Hải Anh',13,False),('Học kỳ: 2026.1',13,False),('',13,False),('2026',14,True)]
for text,size,bold in cover:
 para=first.insert_paragraph_before();para.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER;para.paragraph_format.line_spacing=1.5;para.paragraph_format.space_after=Pt(12)
 run=para.add_run(text);run.font.name='Times New Roman';run.font.size=Pt(size);run.font.bold=bold
h=sec.header.paragraphs[0];h.text='TrungShop — Báo cáo đồ án tốt nghiệp';h.runs[0].font.name='Times New Roman';h.runs[0].font.size=Pt(10)
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER;field(f,' PAGE ','1')
settings=d.settings.element;upd=OxmlElement('w:updateFields');upd.set(qn('w:val'),'true');settings.append(upd)
d.core_properties.title='Báo cáo đồ án tốt nghiệp TrungShop';d.core_properties.author='Trần Quốc Trung';d.core_properties.subject='Website thương mại điện tử kết hợp khai phá luật kết hợp';d.core_properties.keywords='TrungShop, Apriori, FP-Growth, M1, M2, M3'
d.save(p)
print('DOCX formatted',p.stat().st_size)
