from pathlib import Path
import re,json,subprocess
out=Path('/workspace/output');w=Path('/workspace/work')
s='\n\n'.join((w/p).read_text() for p in ['report.md','report-more.md','report-ch5.md','report-ch6.md','appendix.md'])
s=re.sub(r'\*Bảng ([^\n]+)\*',r': Bảng \1',s)
s=re.sub(r'\\tag\{([^}]+)\}',r'\\qquad\\text{(\1)}',s)
s=re.sub(r'(?<![<(])(https://[^\s]+)',r'<\1>',s)
# cite the source where the theoretical section begins
for h in ['## 2.5. Khai phá luật kết hợp','## 2.7. Thuật toán Apriori','## 2.8. Thuật toán FP-Growth','## 2.9. Các độ đo đánh giá luật kết hợp','## 2.10. Khai phá luật kết hợp đa cấp độ','## 2.11. Khai phá luật kết hợp dựa trên ràng buộc']:
 s=s.replace(h+'\n',h+'\n\nCơ sở lý thuyết đối chiếu [1]; các khác biệt hiện thực được chỉ rõ trong phần phân tích mã.\n')
# Each front-matter item is a distinct heading. TOCs have Word field equivalents added later.
s=s.replace('∪', '$\\cup$')
s=s.replace('# DANH MỤC TỪ VIẾT TẮT', '# MỤC LỤC {.unnumbered}\n\n\\tableofcontents\n\n# DANH MỤC HÌNH {.unnumbered}\n\n\\listoffigures\n\n# DANH MỤC BẢNG {.unnumbered}\n\n\\listoftables\n\n# DANH MỤC TỪ VIẾT TẮT')
# Avoid a misleading placeholder in a graph caption.
s=s.replace('theo đồ thị quy định','theo đồ thị quy định')
from PIL import Image
def imgsize(m):
 path=out/m[1]; iw,ih=Image.open(path).size; width=min(15,19.5*iw/ih); return m[0]+'{width='+str(round(width,2))+'cm}'
s=re.sub(r'!\[[^\n]+\]\((hinh_anh_so_do/[^)]+)\)',imgsize,s)
s=s.replace('\\tableofcontents','\\reporttoc').replace('\\listoffigures','\\reportlof').replace('\\listoftables','\\reportlot')
(out/'Bao_cao_do_an_tot_nghiep_TrungShop.md').write_text(s)
header=r'''\usepackage{fontspec}
\usepackage{seqsplit}
\usepackage{xurl}
\DeclareRobustCommand{\codebreak}[1]{{\ttfamily\seqsplit{#1}}}
\usepackage{setspace}
\renewcommand{\normalsize}{\fontsize{13}{15.6}\selectfont}
\AtBeginDocument{\normalsize}
\makeatletter
\newcommand{\reporttoc}{\begingroup\setstretch{1.1}\small\@starttoc{toc}\endgroup}
\newcommand{\reportlof}{\begingroup\setstretch{1.1}\small\@starttoc{lof}\endgroup}
\newcommand{\reportlot}{\begingroup\setstretch{1.1}\small\@starttoc{lot}\endgroup}
\makeatother
\setstretch{1.5}
\usepackage{fancyhdr}
\usepackage{caption}
\captionsetup{labelformat=empty,listformat=empty,font=small,singlelinecheck=false}
\usepackage{etoolbox}
\usepackage{needspace}
\usepackage{float}
\floatplacement{figure}{htbp}
\AtBeginEnvironment{longtable}{\small\setstretch{1.05}}
\AtBeginEnvironment{table}{\small\setstretch{1.05}}
\pretocmd{\section}{\clearpage}{}{}
\pretocmd{\subsection}{\Needspace{8\baselineskip}}{}{}
\pretocmd{\subsubsection}{\Needspace{6\baselineskip}}{}{}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small TrungShop — Báo cáo đồ án tốt nghiệp}
\fancyfoot[C]{\thepage}
\setlength{\headheight}{16pt}
\setlength{\emergencystretch}{3em}
\renewcommand{\contentsname}{Mục lục}
\renewcommand{\listfigurename}{Danh mục hình}
\renewcommand{\listtablename}{Danh mục bảng}
\renewcommand{\figurename}{Hình}
\renewcommand{\tablename}{Bảng}
'''
(w/'header.tex').write_text(header)
cover=r'''\begin{titlepage}
\centering
{\large [CẦN BỔ SUNG: TÊN TRƯỜNG]\\[0.3cm]
[CẦN BỔ SUNG: KHOA / VIỆN]}\\[2.3cm]
{\Large\bfseries BÁO CÁO ĐỒ ÁN TỐT NGHIỆP}\\[1cm]
{\large\bfseries XÂY DỰNG WEBSITE THƯƠNG MẠI ĐIỆN TỬ TRUNGSHOP KẾT HỢP HỆ THỐNG GỢI Ý SẢN PHẨM DỰA TRÊN KHAI PHÁ LUẬT KẾT HỢP}\\[2cm]
\begin{flushleft}
Sinh viên thực hiện: \textbf{Trần Quốc Trung}\\
Mã số sinh viên: 20200648\\
Lớp: ICT-01 K65\\
Giảng viên hướng dẫn: Trần Hải Anh\\
Học kỳ: 2026.1
\end{flushleft}
\vfill
{\large 2026}
\end{titlepage}
\pagenumbering{arabic}
'''
(w/'cover.tex').write_text(cover)
subprocess.run(['pandoc',str(out/'Bao_cao_do_an_tot_nghiep_TrungShop.md'),'-o',str(out/'Bao_cao_do_an_tot_nghiep_TrungShop.docx'),'--resource-path='+str(out)],check=True,cwd=out)
print('Built docx base')
